import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { ErrorProvider } from './contexts/ErrorContext';
import { DataProvider } from './contexts/DataContext';
import { PopupProvider } from './contexts/PopupContext';
import { AuthProvider } from './contexts/AuthContext';
import { NotificationProvider } from './contexts/NotificationContext';
import { GoldSilverProvider } from './contexts/GoldSilverContext';
import { ThemeProvider } from './contexts/ThemeContext';
import Layout from './components/Layout';
import AuthGuard from './components/AuthGuard';
import Dashboard from './pages/Dashboard';
import SalesEntry from './pages/SalesEntry';
import Expenses from './pages/Expenses';
import Customers from './pages/Customers';
import Products from './pages/Products';
import Notifications from './pages/Notifications';
import Webpages from './pages/Webpages';
import GoldSilver from './pages/GoldSilver';
import Settings from './pages/Settings';

function App() {
  return (
    <ErrorProvider>
      <PopupProvider>
        <AuthProvider>
          <ThemeProvider>
            <DataProvider>
              <NotificationProvider>
                <GoldSilverProvider>
                  <Router>
                    <AuthGuard>
                      <Layout>
                        <Routes>
                          <Route path="/webpages" element={<Webpages />} />
                          <Route path="/" element={<Dashboard />} />
                          <Route path="/sales" element={<SalesEntry />} />
                          <Route path="/expenses" element={<Expenses />} />
                          <Route path="/products" element={<Products />} />
                          <Route path="/customers" element={<Customers />} />
                          <Route path="/notifications" element={<Notifications />} />
                          <Route path="/gold-silver" element={<GoldSilver />} />
                          <Route path="/settings" element={<Settings />} />
                        </Routes>
                      </Layout>
                    </AuthGuard>
                  </Router>
                </GoldSilverProvider>
              </NotificationProvider>
            </DataProvider>
          </ThemeProvider>
        </AuthProvider>
      </PopupProvider>
    </ErrorProvider>
  );
}

export default App;
