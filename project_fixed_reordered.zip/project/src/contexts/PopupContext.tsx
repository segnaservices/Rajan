import React, { createContext, useContext, useState, useCallback } from 'react';
import { X, AlertTriangle, CheckCircle, Info, AlertCircle } from 'lucide-react';

interface PopupAction {
  label: string;
  action: () => void;
  variant?: 'primary' | 'secondary' | 'danger' | 'success';
}

interface PopupOptions {
  title: string;
  message: string;
  actions: PopupAction[];
  type?: 'info' | 'warning' | 'error' | 'success' | 'confirm';
  showDontAskAgain?: boolean;
  skipKey?: string;
}

interface PopupContextType {
  showPopup: (options: PopupOptions) => void;
  hidePopup: () => void;
  confirm: (message: string, onConfirm: () => void, options?: Partial<PopupOptions>) => void;
  isSkipped: (key: string) => boolean;
  resetSkips: () => void;
}

const PopupContext = createContext<PopupContextType | null>(null);

export const usePopup = () => {
  const context = useContext(PopupContext);
  if (!context) {
    throw new Error('usePopup must be used within a PopupProvider');
  }
  return context;
};

export const PopupProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [popup, setPopup] = useState<PopupOptions | null>(null);
  const [dontAskAgain, setDontAskAgain] = useState(false);

  const getSkippedActions = () => {
    try {
      return JSON.parse(localStorage.getItem('skippedActions') || '{}');
    } catch {
      return {};
    }
  };

  const setSkippedAction = (key: string) => {
    const skipped = getSkippedActions();
    skipped[key] = true;
    localStorage.setItem('skippedActions', JSON.stringify(skipped));
  };

  const isSkipped = (key: string) => {
    return getSkippedActions()[key] === true;
  };

  const resetSkips = () => {
    localStorage.removeItem('skippedActions');
  };

  const showPopup = useCallback((options: PopupOptions) => {
    if (options.skipKey && isSkipped(options.skipKey)) {
      // Execute the primary action silently
      const primaryAction = options.actions.find(a => a.variant === 'primary' || a.variant === 'danger');
      if (primaryAction) {
        primaryAction.action();
      }
      return;
    }
    
    setPopup(options);
    setDontAskAgain(false);
  }, []);

  const hidePopup = useCallback(() => {
    if (popup?.skipKey && dontAskAgain) {
      setSkippedAction(popup.skipKey);
    }
    setPopup(null);
    setDontAskAgain(false);
  }, [popup, dontAskAgain]);

  const confirm = useCallback((message: string, onConfirm: () => void, options: Partial<PopupOptions> = {}) => {
    showPopup({
      title: options.title || 'Confirm Action',
      message,
      type: 'confirm',
      actions: [
        {
          label: 'Cancel',
          action: hidePopup,
          variant: 'secondary'
        },
        {
          label: options.actions?.[1]?.label || 'Confirm',
          action: () => {
            onConfirm();
            hidePopup();
          },
          variant: 'danger'
        }
      ],
      showDontAskAgain: options.showDontAskAgain,
      skipKey: options.skipKey,
      ...options
    });
  }, [showPopup, hidePopup]);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-6 h-6 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="w-6 h-6 text-yellow-500" />;
      case 'error':
        return <AlertCircle className="w-6 h-6 text-red-500" />;
      case 'info':
        return <Info className="w-6 h-6 text-blue-500" />;
      default:
        return <AlertTriangle className="w-6 h-6 text-gray-500" />;
    }
  };

  const getTypeColors = (type: string) => {
    switch (type) {
      case 'success':
        return 'border-green-500 bg-green-50';
      case 'warning':
        return 'border-yellow-500 bg-yellow-50';
      case 'error':
        return 'border-red-500 bg-red-50';
      case 'info':
        return 'border-blue-500 bg-blue-50';
      default:
        return 'border-gray-500 bg-gray-50';
    }
  };

  const getButtonVariant = (variant: string) => {
    switch (variant) {
      case 'primary':
        return 'bg-blue-600 hover:bg-blue-700 text-white';
      case 'danger':
        return 'bg-red-600 hover:bg-red-700 text-white';
      case 'success':
        return 'bg-green-600 hover:bg-green-700 text-white';
      case 'secondary':
      default:
        return 'bg-gray-200 hover:bg-gray-300 text-gray-800';
    }
  };

  // Handle escape key and outside click
  React.useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && popup) {
        hidePopup();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [popup, hidePopup]);

  return (
    <PopupContext.Provider value={{ showPopup, hidePopup, confirm, isSkipped, resetSkips }}>
      {children}
      
      {popup && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              hidePopup();
            }
          }}
        >
          <div className={`bg-white rounded-xl shadow-2xl max-w-md w-full border-2 ${getTypeColors(popup.type || 'info')}`}>
            <div className="p-6">
              <div className="flex items-start space-x-4">
                {getTypeIcon(popup.type || 'info')}
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {popup.title}
                  </h3>
                  <p className="text-gray-700 mb-4">
                    {popup.message}
                  </p>
                  
                  {popup.showDontAskAgain && (
                    <label className="flex items-center space-x-2 mb-4">
                      <input
                        type="checkbox"
                        checked={dontAskAgain}
                        onChange={(e) => setDontAskAgain(e.target.checked)}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-600">Don't ask again</span>
                    </label>
                  )}
                  
                  <div className="flex space-x-3 justify-end">
                    {popup.actions.map((action, index) => (
                      <button
                        key={index}
                        onClick={action.action}
                        className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${getButtonVariant(action.variant || 'secondary')}`}
                      >
                        {action.label}
                      </button>
                    ))}
                  </div>
                </div>
                <button
                  onClick={hidePopup}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </PopupContext.Provider>
  );
};