import React, { createContext, useContext, useState, useEffect } from 'react';
import { useError } from './ErrorContext';

export interface Customer {
  id: string;
  ref: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  address: string;
  createdAt: string;
}

export interface Product {
  id: string;
  ref: string;
  name: string;
  price: number;
  category: string;
  stock: number;
  description: string;
  type: 'product' | 'service';
  createdAt?: string;
}

export interface SalesEntry {
  id: string;
  type: 'Sale';
  date: string;
  ref: string;
  customerId: string;
  customerName: string;
  phone: string;
  payment: string;
  items: SalesItem[];
  subtotal: number;
  discount: number;
  grandTotal: number;
  status: 'paid' | 'not_paid';
}

export interface SalesItem {
  productId: string;
  name: string;
  qty: number;
  price: number;
  total: number;
}

export interface Expense {
  id: string;
  type: 'Expense';
  date: string;
  ref: string;
  description: string;
  note?: string;
  category: string;
  amount: number;
  payment: string;
}

export interface Webpage {
  id: string;
  name: string;
  url: string;
  icon: string;
  stretch: boolean;
}

export interface Company {
  name: string;
  phone: string;
  email: string;
  gst: string;
  address: string;
}

interface DataContextType {
  customers: Customer[];
  products: Product[];
  salesEntries: SalesEntry[];
  expenses: Expense[];
  webpages: Webpage[];
  company: Company;
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt'>) => void;
  updateCustomer: (id: string, customer: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addSalesEntry: (entry: Omit<SalesEntry, 'id'>) => void;
  updateSalesEntry: (id: string, entry: Partial<SalesEntry>) => void;
  deleteSalesEntry: (id: string) => void;
  addExpense: (expense: Omit<Expense, 'id'>) => void;
  updateExpense: (id: string, expense: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;
  addWebpage: (webpage: Omit<Webpage, 'id'>) => void;
  updateWebpage: (id: string, webpage: Partial<Webpage>) => void;
  deleteWebpage: (id: string) => void;
  updateCompany: (company: Partial<Company>) => void;
  searchCustomers: (query: string) => Customer[];
  searchProducts: (query: string) => Product[];
  generateRef: (prefix: string) => string;
  exportToExcel: (type: 'sales' | 'expenses' | 'all') => void;
  importFromExcel: (file: File, type: 'sales' | 'expenses' | 'all') => Promise<void>;
  exportBackup: () => void;
  importBackup: (file: File) => Promise<void>;
  isLoading: boolean;
}

const DataContext = createContext<DataContextType | null>(null);

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

const generateId = () => Math.random().toString(36).substr(2, 9);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [salesEntries, setSalesEntries] = useState<SalesEntry[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [webpages, setWebpages] = useState<Webpage[]>([]);
  const [company, setCompany] = useState<Company>({
    name: 'Segna Pro',
    phone: '',
    email: '',
    gst: '',
    address: ''
  });
  const [isLoading, setIsLoading] = useState(true);
  const { showError } = useError();

  // Initialize with sample data
  useEffect(() => {
    try {
      const savedCustomers = localStorage.getItem('customers');
      const savedProducts = localStorage.getItem('products');
      const savedSalesEntries = localStorage.getItem('salesEntries');
      const savedExpenses = localStorage.getItem('expenses');
      const savedWebpages = localStorage.getItem('webpages');
      const savedCompany = localStorage.getItem('company');

      if (savedCustomers) {
        setCustomers(JSON.parse(savedCustomers));
      } else {
        const sampleCustomers: Customer[] = [
          {
            id: '1',
            ref: 'CUST-001',
            name: 'John Smith',
            email: 'john@example.com',
            phone: '+91-9876543210',
            company: 'Tech Solutions Inc',
            address: '123 Business St, Mumbai, Maharashtra 400001',
            createdAt: new Date().toISOString(),
          },
          {
            id: '2',
            ref: 'CUST-002',
            name: 'Sarah Johnson',
            email: 'sarah@example.com',
            phone: '+91-9876543211',
            company: 'Marketing Pro',
            address: '456 Commerce Ave, Delhi, Delhi 110001',
            createdAt: new Date().toISOString(),
          },
          {
            id: '3',
            ref: 'CUST-003',
            name: 'Michael Brown',
            email: 'michael@example.com',
            phone: '+91-9876543212',
            company: 'Design Studio',
            address: '789 Creative Blvd, Bangalore, Karnataka 560001',
            createdAt: new Date().toISOString(),
          },
        ];
        setCustomers(sampleCustomers);
      }

      if (savedProducts) {
        setProducts(JSON.parse(savedProducts));
      } else {
        const sampleProducts: Product[] = [
          {
            id: '1',
            ref: 'PROD-001',
            name: 'MacBook Pro 16"',
            price: 199999,
            category: 'Electronics',
            stock: 15,
            description: 'High-performance laptop for professionals',
            type: 'product',
            createdAt: new Date().toISOString(),
          },
          {
            id: '2',
            ref: 'PROD-002',
            name: 'iPhone 15 Pro',
            price: 134900,
            category: 'Electronics',
            stock: 25,
            description: 'Latest smartphone with advanced features',
            type: 'product',
            createdAt: new Date().toISOString(),
          },
          {
            id: '3',
            ref: 'PROD-003',
            name: 'Web Development Service',
            price: 5000,
            category: 'Services',
            stock: 0,
            description: 'Professional web development per hour',
            type: 'service',
            createdAt: new Date().toISOString(),
          },
          {
            id: '4',
            ref: 'PROD-004',
            name: 'Digital Marketing Consultation',
            price: 3000,
            category: 'Services',
            stock: 0,
            description: 'Expert digital marketing consultation',
            type: 'service',
            createdAt: new Date().toISOString(),
          },
        ];
        setProducts(sampleProducts);
      }

      if (savedSalesEntries) {
        setSalesEntries(JSON.parse(savedSalesEntries));
      }

      if (savedExpenses) {
        setExpenses(JSON.parse(savedExpenses));
      }

      if (savedWebpages) {
        setWebpages(JSON.parse(savedWebpages));
      }

      if (savedCompany) {
        setCompany(JSON.parse(savedCompany));
      }
    } catch (error) {
      showError('Failed to load data from local storage');
    } finally {
      setIsLoading(false);
    }
  }, [showError]);

  // Save to localStorage whenever data changes
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('customers', JSON.stringify(customers));
    }
  }, [customers, isLoading]);

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('products', JSON.stringify(products));
    }
  }, [products, isLoading]);

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('salesEntries', JSON.stringify(salesEntries));
    }
  }, [salesEntries, isLoading]);

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('expenses', JSON.stringify(expenses));
    }
  }, [expenses, isLoading]);

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('webpages', JSON.stringify(webpages));
    }
  }, [webpages, isLoading]);

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('company', JSON.stringify(company));
    }
  }, [company, isLoading]);

  const generateRef = (prefix: string) => {
    let entries: any[] = [];
    let nextNumber = 1;
    
    switch (prefix) {
      case 'INV':
        entries = salesEntries;
        break;
      case 'EXP':
        entries = expenses;
        break;
      case 'CUST':
        entries = customers;
        break;
      case 'PROD':
        entries = products;
        break;
    }
    
    // Find the highest existing number for this prefix
    const existingRefs = entries
      .map(entry => entry.ref)
      .filter(ref => ref && ref.startsWith(prefix + '-'))
      .map(ref => {
        const num = parseInt(ref.split('-')[1]);
        return isNaN(num) ? 0 : num;
      });
    
    if (existingRefs.length > 0) {
      nextNumber = Math.max(...existingRefs) + 1;
    }
    
    return `${prefix}-${nextNumber.toString().padStart(3, '0')}`;
  };

  const addCustomer = (customerData: Omit<Customer, 'id' | 'createdAt'>) => {
    try {
      const newCustomer: Customer = {
        ...customerData,
        id: generateId(),
        ref: generateRef('CUST'),
        createdAt: new Date().toISOString(),
      };
      setCustomers(prev => [...prev, newCustomer]);
      showError('Customer added successfully', 'info');
    } catch (error) {
      showError('Failed to add customer');
    }
  };

  const updateCustomer = (id: string, updates: Partial<Customer>) => {
    try {
      setCustomers(prev =>
        prev.map(customer => customer.id === id ? { ...customer, ...updates } : customer)
      );
      showError('Customer updated successfully', 'info');
    } catch (error) {
      showError('Failed to update customer');
    }
  };

  const deleteCustomer = (id: string) => {
    try {
      setCustomers(prev => prev.filter(customer => customer.id !== id));
      showError('Customer deleted successfully', 'info');
    } catch (error) {
      showError('Failed to delete customer');
    }
  };

  const addProduct = (productData: Omit<Product, 'id'>) => {
    try {
      console.log('Adding product with data:', productData);
      const newProduct: Product = {
        ...productData,
        id: generateId(),
        ref: generateRef('PROD'),
        createdAt: new Date().toISOString(),
      };
      console.log('New product created:', newProduct);
      setProducts(prev => [...prev, newProduct]);
      console.log('Products after adding:', [...products, newProduct]);
      showError(`${productData.type === 'service' ? 'Service' : 'Product'} added successfully!`, 'info');
    } catch (error) {
      console.error('Error adding product:', error);
      showError(`Failed to add ${productData.type === 'service' ? 'service' : 'product'}`);
    }
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    try {
      setProducts(prev =>
        prev.map(product => product.id === id ? { ...product, ...updates } : product)
      );
      showError('Product updated successfully', 'info');
    } catch (error) {
      showError('Failed to update product');
    }
  };

  const deleteProduct = (id: string) => {
    try {
      setProducts(prev => prev.filter(product => product.id !== id));
      showError('Product deleted successfully', 'info');
    } catch (error) {
      showError('Failed to delete product');
    }
  };

  const addSalesEntry = (entryData: Omit<SalesEntry, 'id'>) => {
    try {
      const newEntry: SalesEntry = {
        ...entryData,
        id: generateId(),
      };
      setSalesEntries(prev => [...prev, newEntry]);
      showError('Sales entry added successfully', 'info');
    } catch (error) {
      showError('Failed to add sales entry');
    }
  };

  const updateSalesEntry = (id: string, updates: Partial<SalesEntry>) => {
    try {
      setSalesEntries(prev =>
        prev.map(entry => entry.id === id ? { ...entry, ...updates } : entry)
      );
      showError('Sales entry updated successfully', 'info');
    } catch (error) {
      showError('Failed to update sales entry');
    }
  };

  const deleteSalesEntry = (id: string) => {
    try {
      setSalesEntries(prev => prev.filter(entry => entry.id !== id));
      showError('Sales entry deleted successfully', 'info');
    } catch (error) {
      showError('Failed to delete sales entry');
    }
  };

  const addExpense = (expenseData: Omit<Expense, 'id'>) => {
    try {
      const newExpense: Expense = {
        ...expenseData,
        id: generateId(),
      };
      setExpenses(prev => [...prev, newExpense]);
      showError('Expense added successfully', 'info');
    } catch (error) {
      showError('Failed to add expense');
    }
  };

  const updateExpense = (id: string, updates: Partial<Expense>) => {
    try {
      setExpenses(prev =>
        prev.map(expense => expense.id === id ? { ...expense, ...updates } : expense)
      );
      showError('Expense updated successfully', 'info');
    } catch (error) {
      showError('Failed to update expense');
    }
  };

  const deleteExpense = (id: string) => {
    try {
      setExpenses(prev => prev.filter(expense => expense.id !== id));
      showError('Expense deleted successfully', 'info');
    } catch (error) {
      showError('Failed to delete expense');
    }
  };

  const addWebpage = (webpageData: Omit<Webpage, 'id'>) => {
    try {
      const newWebpage: Webpage = {
        ...webpageData,
        id: generateId(),
      };
      setWebpages(prev => [...prev, newWebpage]);
      showError('Webpage added successfully', 'info');
    } catch (error) {
      showError('Failed to add webpage');
    }
  };

  const updateWebpage = (id: string, updates: Partial<Webpage>) => {
    try {
      setWebpages(prev =>
        prev.map(webpage => webpage.id === id ? { ...webpage, ...updates } : webpage)
      );
      showError('Webpage updated successfully', 'info');
    } catch (error) {
      showError('Failed to update webpage');
    }
  };

  const deleteWebpage = (id: string) => {
    try {
      setWebpages(prev => prev.filter(webpage => webpage.id !== id));
      showError('Webpage deleted successfully', 'info');
    } catch (error) {
      showError('Failed to delete webpage');
    }
  };

  const updateCompany = (updates: Partial<Company>) => {
    try {
      setCompany(prev => ({ ...prev, ...updates }));
      showError('Company information updated successfully', 'info');
    } catch (error) {
      showError('Failed to update company information');
    }
  };

  const searchCustomers = (query: string): Customer[] => {
    if (!query.trim()) return customers.slice(0, 8);
    
    const lowercaseQuery = query.toLowerCase();
    return customers.filter(customer =>
      customer.name.toLowerCase().includes(lowercaseQuery) ||
      customer.email.toLowerCase().includes(lowercaseQuery) ||
      customer.phone.toLowerCase().includes(lowercaseQuery) ||
      customer.company.toLowerCase().includes(lowercaseQuery)
    ).slice(0, 8);
  };

  const searchProducts = (query: string): Product[] => {
    if (!query.trim()) return products.slice(0, 8);
    
    const lowercaseQuery = query.toLowerCase();
    return products.filter(product =>
      product.name.toLowerCase().includes(lowercaseQuery) ||
      product.category.toLowerCase().includes(lowercaseQuery) ||
      product.description.toLowerCase().includes(lowercaseQuery)
    ).slice(0, 8);
  };

  const exportToExcel = async (type: 'sales' | 'expenses' | 'all') => {
    try {
      const XLSX = await import('xlsx');
      const wb = XLSX.utils.book_new();

      if (type === 'sales' || type === 'all') {
        const salesData = salesEntries.map(sale => ({
          Date: sale.date,
          'Invoice Ref': sale.ref,
          Customer: sale.customerName,
          Phone: sale.phone,
          'Payment Method': sale.payment,
          'Items Count': sale.items.length,
          Subtotal: sale.subtotal,
          Discount: sale.discount,
          'Grand Total': sale.grandTotal,
          Status: sale.status
        }));
        
        if (salesData.length > 0) {
          const ws = XLSX.utils.json_to_sheet(salesData);
          XLSX.utils.book_append_sheet(wb, ws, 'Sales');
        }
      }

      if (type === 'expenses' || type === 'all') {
        const expensesData = expenses.map(expense => ({
          Date: expense.date,
          Reference: expense.ref,
          Description: expense.description,
          Note: expense.note || '',
          Category: expense.category,
          Amount: expense.amount,
          'Payment Method': expense.payment
        }));
        
        if (expensesData.length > 0) {
          const ws = XLSX.utils.json_to_sheet(expensesData);
          XLSX.utils.book_append_sheet(wb, ws, 'Expenses');
        }
      }

      if (type === 'all') {
        // Add customers sheet
        if (customers.length > 0) {
          const customersData = customers.map(customer => ({
            Name: customer.name,
            Email: customer.email,
            Phone: customer.phone,
            Company: customer.company,
            Address: customer.address,
            'Created At': customer.createdAt
          }));
          const ws = XLSX.utils.json_to_sheet(customersData);
          XLSX.utils.book_append_sheet(wb, ws, 'Customers');
        }

        // Add products sheet
        if (products.length > 0) {
          const productsData = products.map(product => ({
            Name: product.name,
            Price: product.price,
            Category: product.category,
            Stock: product.stock,
            Description: product.description,
            Type: product.type
          }));
          const ws = XLSX.utils.json_to_sheet(productsData);
          XLSX.utils.book_append_sheet(wb, ws, 'Products');
        }
      }

      const filename = type === 'all' 
        ? `Segna_Complete_Data_${new Date().toISOString().slice(0, 10)}.xlsx`
        : `${type.charAt(0).toUpperCase() + type.slice(1)}_${new Date().toISOString().slice(0, 10)}.xlsx`;
      
      XLSX.writeFile(wb, filename);
      showError(`${type === 'all' ? 'All data' : type} exported to Excel successfully!`, 'info');
    } catch (error) {
      showError('Failed to export to Excel');
    }
  };

  const importFromExcel = async (file: File, type: 'sales' | 'expenses' | 'all') => {
    try {
      const XLSX = await import('xlsx');
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data, { type: 'array' });

      if (type === 'sales' || type === 'all') {
        const salesSheet = workbook.Sheets['Sales'] || workbook.Sheets[workbook.SheetNames[0]];
        if (salesSheet) {
          const jsonData = XLSX.utils.sheet_to_json(salesSheet);
          const newSales: SalesEntry[] = jsonData.map((row: any) => ({
            id: generateId(),
            type: 'sale' as const,
            date: row.Date || new Date().toISOString().slice(0, 10),
            ref: row['Invoice Ref'] || generateRef('INV'),
            customerId: '',
            customerName: row.Customer || 'Walk-in',
            phone: row.Phone || '',
            payment: row['Payment Method'] || 'Cash',
            items: [],
            subtotal: row.Subtotal || 0,
            discount: row.Discount || 0,
            grandTotal: row['Grand Total'] || 0,
            status: (row.Status as 'pending' | 'completed' | 'cancelled') || 'completed'
          }));
          setSalesEntries(prev => [...prev, ...newSales]);
        }
      }
      
      if (type === 'expenses' || type === 'all') {
        const expensesSheet = workbook.Sheets['Expenses'] || (type === 'expenses' ? workbook.Sheets[workbook.SheetNames[0]] : null);
        if (expensesSheet) {
          const jsonData = XLSX.utils.sheet_to_json(expensesSheet);
          const newExpenses: Expense[] = jsonData.map((row: any) => ({
            id: generateId(),
            type: 'expense' as const,
            date: row.Date || new Date().toISOString().slice(0, 10),
            ref: row.Reference || generateRef('EXP'),
            description: row.Description || '',
            note: row.Note || '',
            category: row.Category || 'General',
            amount: row.Amount || 0,
            payment: row['Payment Method'] || 'Cash'
          }));
          setExpenses(prev => [...prev, ...newExpenses]);
        }
      }
      
      if (type === 'all') {
        // Import customers
        const customersSheet = workbook.Sheets['Customers'];
        if (customersSheet) {
          const jsonData = XLSX.utils.sheet_to_json(customersSheet);
          const newCustomers: Customer[] = jsonData.map((row: any) => ({
            id: generateId(),
            name: row.Name || '',
            email: row.Email || '',
            phone: row.Phone || '',
            company: row.Company || '',
            address: row.Address || '',
            createdAt: row['Created At'] || new Date().toISOString()
          }));
          setCustomers(prev => [...prev, ...newCustomers]);
        }
        
        // Import products
        const productsSheet = workbook.Sheets['Products'];
        if (productsSheet) {
          const jsonData = XLSX.utils.sheet_to_json(productsSheet);
          const newProducts: Product[] = jsonData.map((row: any) => ({
            id: generateId(),
            name: row.Name || '',
            price: row.Price || 0,
            category: row.Category || '',
            stock: row.Stock || 0,
            description: row.Description || '',
            type: (row.Type as 'product' | 'service') || 'product',
            createdAt: new Date().toISOString()
          }));
          setProducts(prev => [...prev, ...newProducts]);
        }
      }
      
      if (type === 'sales') {
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        const newSales: SalesEntry[] = jsonData.map((row: any) => ({
          id: generateId(),
          type: 'Sale' as const,
          date: row.Date || new Date().toISOString().slice(0, 10),
          ref: row['Invoice Ref'] || generateRef('INV'),
          customerId: '',
          customerName: row.Customer || 'Walk-in',
          phone: row.Phone || '',
          payment: row['Payment Method'] || 'Cash',
          items: [],
          subtotal: row.Subtotal || 0,
          discount: row.Discount || 0,
          grandTotal: row['Grand Total'] || 0,
          status: (row.Status as 'pending' | 'completed' | 'cancelled') || 'completed'
        }));
        setSalesEntries(prev => [...prev, ...newSales]);
      }
      
      if (type === 'expenses') {
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        const newExpenses: Expense[] = jsonData.map((row: any) => ({
          id: generateId(),
          type: 'Expense' as const,
          date: row.Date || new Date().toISOString().slice(0, 10),
          ref: row.Reference || generateRef('EXP'),
          description: row.Description || '',
          note: row.Note || '',
          category: row.Category || 'General',
          amount: row.Amount || 0,
          payment: row['Payment Method'] || 'Cash'
        }));
        setExpenses(prev => [...prev, ...newExpenses]);
      }

      showError(`${type === 'all' ? 'All data' : type} imported from Excel successfully!`, 'info');
    } catch (error) {
      showError('Failed to import from Excel');
    }
  };

  const exportBackup = () => {
    try {
      const backupData = {
        customers,
        products,
        salesEntries,
        expenses,
        webpages,
        company,
        exportDate: new Date().toISOString(),
        version: '2.0'
      };

      const jsonStr = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Segna_Pro_Backup_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);

      showError('Backup exported successfully!', 'info');
    } catch (error) {
      showError('Failed to export backup');
    }
  };

  const importBackup = async (file: File) => {
    try {
      const text = await file.text();
      const backupData = JSON.parse(text);

      if (backupData.customers) setCustomers(backupData.customers);
      if (backupData.products) setProducts(backupData.products);
      if (backupData.salesEntries) setSalesEntries(backupData.salesEntries);
      if (backupData.expenses) setExpenses(backupData.expenses);
      if (backupData.webpages) setWebpages(backupData.webpages);
      if (backupData.company) setCompany(backupData.company);

      showError('Backup imported successfully!', 'info');
    } catch (error) {
      showError('Failed to import backup - invalid file format');
    }
  };

  return (
    <DataContext.Provider value={{
      customers,
      products,
      salesEntries,
      expenses,
      webpages,
      company,
      addCustomer,
      updateCustomer,
      deleteCustomer,
      addProduct,
      updateProduct,
      deleteProduct,
      addSalesEntry,
      updateSalesEntry,
      deleteSalesEntry,
      addExpense,
      updateExpense,
      deleteExpense,
      addWebpage,
      updateWebpage,
      deleteWebpage,
      updateCompany,
      searchCustomers,
      searchProducts,
      generateRef,
      exportToExcel,
      importFromExcel,
      exportBackup,
      importBackup,
      isLoading,
    }}>
      {children}
    </DataContext.Provider>
  );
};