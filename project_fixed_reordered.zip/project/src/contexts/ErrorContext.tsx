import React, { createContext, useContext, useState, useCallback } from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface ErrorContextType {
  showError: (message: string, type?: 'error' | 'warning' | 'info') => void;
  clearError: () => void;
}

const ErrorContext = createContext<ErrorContextType | null>(null);

export const useError = () => {
  const context = useContext(ErrorContext);
  if (!context) {
    throw new Error('useError must be used within an ErrorProvider');
  }
  return context;
};

interface ErrorProviderProps {
  children: React.ReactNode;
}

export const ErrorProvider: React.FC<ErrorProviderProps> = ({ children }) => {
  const [error, setError] = useState<{ message: string; type: 'error' | 'warning' | 'info' } | null>(null);

  const showError = useCallback((message: string, type: 'error' | 'warning' | 'info' = 'error') => {
    setError({ message, type });
    
    // Auto-clear after 5 seconds for non-error types
    if (type !== 'error') {
      setTimeout(() => setError(null), 5000);
    }
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const getErrorStyles = (type: string) => {
    switch (type) {
      case 'warning':
        return 'bg-yellow-50 border-yellow-200 text-yellow-800';
      case 'info':
        return 'bg-blue-50 border-blue-200 text-blue-800';
      default:
        return 'bg-red-50 border-red-200 text-red-800';
    }
  };

  return (
    <ErrorContext.Provider value={{ showError, clearError }}>
      {children}
      {error && (
        <div className="fixed top-4 right-4 z-50 max-w-md animate-in slide-in-from-right-full duration-300">
          <div className={`p-4 rounded-lg border shadow-lg ${getErrorStyles(error.type)}`}>
            <div className="flex items-start">
              <AlertTriangle className="w-5 h-5 mt-0.5 mr-3 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-sm font-medium">{error.message}</p>
              </div>
              <button
                onClick={clearError}
                className="ml-3 flex-shrink-0 opacity-70 hover:opacity-100 transition-opacity"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </ErrorContext.Provider>
  );
};