import React, { createContext, useContext, useState, useEffect } from 'react';
import { formatDateTime } from '../utils/dateUtils';

export interface Notification {
  id: string;
  title: string;
  content: string;
  source: string;
  category: string;
  url?: string;
  date: string;
  isRead: boolean;
  priority: 'low' | 'medium' | 'high';
}

interface NotificationSettings {
  enabled: boolean;
  autoRefresh: number; // minutes
  goldSilverAlerts: boolean;
  examNotifications: boolean;
  governmentJobAlerts: boolean;
  bankExamAlerts: boolean;
  sources: string[];
}

interface NotificationContextType {
  notifications: Notification[];
  settings: NotificationSettings;
  isLoading: boolean;
  addNotification: (notification: Omit<Notification, 'id' | 'date' | 'isRead'>) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
  updateSettings: (settings: Partial<NotificationSettings>) => void;
  refreshNotifications: () => Promise<void>;
  getNotificationsBySource: () => { [key: string]: Notification[] };
  getNotificationsByCategory: () => { [key: string]: Notification[] };
}

const defaultSettings: NotificationSettings = {
  enabled: true,
  autoRefresh: 30,
  goldSilverAlerts: true,
  examNotifications: true,
  governmentJobAlerts: true,
  bankExamAlerts: true,
  sources: ['RBI', 'Income Tax', 'GST Portal', 'Banks', 'Stock Exchange', 'UPSC', 'SSC', 'Railway', 'Banking', 'State PSC'],
};

const NotificationContext = createContext<NotificationContextType | null>(null);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [settings, setSettings] = useState<NotificationSettings>(defaultSettings);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const savedNotifications = localStorage.getItem('segna-notifications');
    const savedSettings = localStorage.getItem('segna-notification-settings');
    
    if (savedNotifications) {
      try {
        setNotifications(JSON.parse(savedNotifications));
      } catch (error) {
        console.error('Failed to load notifications:', error);
      }
    }
    
    if (savedSettings) {
      try {
        setSettings(JSON.parse(savedSettings));
      } catch (error) {
        console.error('Failed to load notification settings:', error);
      }
    }

    // Add sample notifications
    if (!savedNotifications) {
      const sampleNotifications: Notification[] = [
        {
          id: '1',
          title: 'UPSC Civil Services Exam 2024',
          content: 'UPSC Civil Services Preliminary Exam 2024 notification released. Last date to apply: 15th February 2024.',
          source: 'UPSC',
          category: 'Government Jobs',
          url: 'https://upsc.gov.in',
          date: new Date().toISOString(),
          isRead: false,
          priority: 'high',
        },
        {
          id: '2',
          title: 'SBI PO Recruitment 2024',
          content: 'State Bank of India announces Probationary Officer recruitment. 2000+ vacancies available. Apply before 28th January 2024.',
          source: 'Banking',
          category: 'Bank Exams',
          url: 'https://sbi.co.in/careers',
          date: new Date(Date.now() - 86400000).toISOString(),
          isRead: false,
          priority: 'high',
        },
        {
          id: '3',
          title: 'SSC CGL 2024 Notification',
          content: 'Staff Selection Commission Combined Graduate Level Examination 2024 notification expected soon. Stay tuned for updates.',
          source: 'SSC',
          category: 'Government Jobs',
          url: 'https://ssc.nic.in',
          date: new Date(Date.now() - 172800000).toISOString(),
          isRead: false,
          priority: 'medium',
        },
        {
          id: '4',
          title: 'Railway Group D Recruitment',
          content: 'Indian Railways announces Group D recruitment for 35,000+ posts. Online application starts from 5th February 2024.',
          source: 'Railway',
          category: 'Government Jobs',
          url: 'https://rrc.indianrailways.gov.in',
          date: new Date(Date.now() - 259200000).toISOString(),
          isRead: false,
          priority: 'high',
        },
        {
          id: '5',
          title: 'IBPS Clerk Exam Results',
          content: 'Institute of Banking Personnel Selection announces IBPS Clerk Preliminary Exam results. Check your result now.',
          source: 'Banking',
          category: 'Bank Exams',
          url: 'https://ibps.in',
          date: new Date(Date.now() - 345600000).toISOString(),
          isRead: true,
          priority: 'medium',
        },
        {
          id: '6',
          title: 'TNPSC Group 1 Services',
          content: 'Tamil Nadu Public Service Commission announces Group 1 Services recruitment. 120 vacancies for various departments.',
          source: 'State PSC',
          category: 'Government Jobs',
          url: 'https://tnpsc.gov.in',
          date: new Date(Date.now() - 432000000).toISOString(),
          isRead: false,
          priority: 'medium',
        },
        {
          id: '7',
          title: 'RBI Grade B Officer Recruitment',
          content: 'Reserve Bank of India announces Grade B Officer recruitment 2024. 294 vacancies across various streams.',
          source: 'RBI',
          category: 'Bank Exams',
          url: 'https://rbi.org.in',
          date: new Date(Date.now() - 518400000).toISOString(),
          isRead: true,
          priority: 'high',
        },
        {
          id: '8',
          title: 'GST Return Filing Reminder',
          content: 'GSTR-3B filing due date is approaching. File your return by 20th of this month.',
          source: 'GST Portal',
          category: 'Tax',
          url: 'https://gst.gov.in',
          date: new Date(Date.now() - 604800000).toISOString(),
          isRead: false,
          priority: 'medium',
        },
      ];
      setNotifications(sampleNotifications);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('segna-notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('segna-notification-settings', JSON.stringify(settings));
  }, [settings]);

  const addNotification = (notificationData: Omit<Notification, 'id' | 'date' | 'isRead'>) => {
    const newNotification: Notification = {
      ...notificationData,
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toISOString(),
      isRead: false,
    };
    setNotifications(prev => [newNotification, ...prev]);
  };

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(notification =>
        notification.id === id ? { ...notification, isRead: true } : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notification => ({ ...notification, isRead: true }))
    );
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id));
  };

  const updateSettings = (newSettings: Partial<NotificationSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const refreshNotifications = async () => {
    if (!settings.enabled) return;
    
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Add random exam notifications to simulate real updates
      const examNotifications = [
        {
          title: 'UPSC CAPF Exam Date Announced',
          content: 'Central Armed Police Forces (Assistant Commandants) Examination 2024 scheduled for 20th August 2024.',
          source: 'UPSC',
          category: 'Government Jobs',
          url: 'https://upsc.gov.in',
          priority: 'medium' as const,
        },
        {
          title: 'IBPS RRB Notification Expected',
          content: 'IBPS Regional Rural Banks recruitment notification expected in the first week of June 2024.',
          source: 'Banking',
          category: 'Bank Exams',
          url: 'https://ibps.in',
          priority: 'high' as const,
        },
        {
          title: 'SSC CHSL Tier 2 Results',
          content: 'Staff Selection Commission Combined Higher Secondary Level Tier 2 results declared. Check your result.',
          source: 'SSC',
          category: 'Government Jobs',
          url: 'https://ssc.nic.in',
          priority: 'medium' as const,
        },
        {
          title: 'Railway NTPC Recruitment',
          content: 'Railway Non-Technical Popular Categories recruitment for 35,000+ posts. Application starts soon.',
          source: 'Railway',
          category: 'Government Jobs',
          url: 'https://rrc.indianrailways.gov.in',
          priority: 'high' as const,
        }
      ];
      
      // Add a random notification
      const randomNotification = examNotifications[Math.floor(Math.random() * examNotifications.length)];
      addNotification(randomNotification);
    } catch (error) {
      console.error('Failed to refresh notifications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getNotificationsBySource = () => {
    return notifications.reduce((acc, notification) => {
      if (!acc[notification.source]) {
        acc[notification.source] = [];
      }
      acc[notification.source].push(notification);
      return acc;
    }, {} as { [key: string]: Notification[] });
  };

  const getNotificationsByCategory = () => {
    return notifications.reduce((acc, notification) => {
      if (!acc[notification.category]) {
        acc[notification.category] = [];
      }
      acc[notification.category].push(notification);
      return acc;
    }, {} as { [key: string]: Notification[] });
  };

  return (
    <NotificationContext.Provider value={{
      notifications,
      settings,
      isLoading,
      addNotification,
      markAsRead,
      markAllAsRead,
      deleteNotification,
      updateSettings,
      refreshNotifications,
      getNotificationsBySource,
      getNotificationsByCategory,
    }}>
      {children}
    </NotificationContext.Provider>
  );
};