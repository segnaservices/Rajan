import React, { createContext, useContext, useState, useEffect } from 'react';

interface AuthContextType {
  isAuthenticated: boolean;
  login: (pin: string, otp?: string) => boolean;
  logout: () => void;
  isAuthEnabled: boolean;
  setAuthEnabled: (enabled: boolean) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAuthEnabled, setIsAuthEnabled] = useState(false);

  useEffect(() => {
    const authEnabled = localStorage.getItem('authEnabled') === 'true';
    const sessionAuth = sessionStorage.getItem('authenticated') === 'true';
    
    setIsAuthEnabled(authEnabled);
    setIsAuthenticated(!authEnabled || sessionAuth);
  }, []);

  const login = (pin: string, otp?: string) => {
    // Simple PIN validation (can be enhanced)
    const savedPin = localStorage.getItem('appPin') || '1234';
    
    if (pin === savedPin) {
      setIsAuthenticated(true);
      sessionStorage.setItem('authenticated', 'true');
      return true;
    }
    
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('authenticated');
  };

  const handleSetAuthEnabled = (enabled: boolean) => {
    setIsAuthEnabled(enabled);
    localStorage.setItem('authEnabled', enabled.toString());
    
    if (!enabled) {
      setIsAuthenticated(true);
      sessionStorage.setItem('authenticated', 'true');
    }
  };

  return (
    <AuthContext.Provider value={{
      isAuthenticated,
      login,
      logout,
      isAuthEnabled,
      setAuthEnabled: handleSetAuthEnabled
    }}>
      {children}
    </AuthContext.Provider>
  );
};