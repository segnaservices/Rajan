import React, { createContext, useContext, useState, useEffect } from 'react';

export interface ThemeSettings {
  mode: 'light' | 'dark' | 'auto';
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
  };
  fonts: {
    family: string;
    size: number;
    lineSpacing: number;
  };
  layout: {
    sidebar: 'left' | 'right' | 'top';
    style: 'compact' | 'full';
    cardShape: 'rounded' | 'square';
    spacing: 'tight' | 'normal' | 'loose';
  };
  components: {
    buttonSize: 'small' | 'medium' | 'large';
    buttonShape: 'pill' | 'rounded' | 'rectangle';
    iconSize: number;
    shadows: boolean;
  };
  background: {
    type: 'color' | 'gradient' | 'pattern' | 'image';
    value: string;
  };
}

interface ThemeContextType {
  theme: ThemeSettings;
  updateTheme: (updates: Partial<ThemeSettings>) => void;
  resetTheme: () => void;
  applyTheme: () => void;
  savePreset: (name: string) => void;
  loadPreset: (name: string) => void;
  getPresets: () => string[];
}

const defaultTheme: ThemeSettings = {
  mode: 'dark',
  colors: {
    primary: '#3b82f6',
    secondary: '#8b5cf6',
    accent: '#f59e0b',
    background: '#0f172a',
    text: '#ffffff',
  },
  fonts: {
    family: 'Inter, system-ui, sans-serif',
    size: 14,
    lineSpacing: 1.5,
  },
  layout: {
    sidebar: 'top',
    style: 'full',
    cardShape: 'rounded',
    spacing: 'normal',
  },
  components: {
    buttonSize: 'medium',
    buttonShape: 'rounded',
    iconSize: 20,
    shadows: true,
  },
  background: {
    type: 'gradient',
    value: 'linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%)',
  },
};

const ThemeContext = createContext<ThemeContextType | null>(null);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<ThemeSettings>(defaultTheme);

  useEffect(() => {
    const savedTheme = localStorage.getItem('segna-theme');
    if (savedTheme) {
      try {
        setTheme(JSON.parse(savedTheme));
      } catch (error) {
        console.error('Failed to load saved theme:', error);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('segna-theme', JSON.stringify(theme));
    applyTheme();
  }, [theme]);

  const updateTheme = (updates: Partial<ThemeSettings>) => {
    setTheme(prev => ({
      ...prev,
      ...updates,
      colors: { ...prev.colors, ...(updates.colors || {}) },
      fonts: { ...prev.fonts, ...(updates.fonts || {}) },
      layout: { ...prev.layout, ...(updates.layout || {}) },
      components: { ...prev.components, ...(updates.components || {}) },
      background: { ...prev.background, ...(updates.background || {}) },
    }));
  };

  const resetTheme = () => {
    setTheme(defaultTheme);
  };

  const applyTheme = () => {
    const root = document.documentElement;
    
    // Apply CSS custom properties
    root.style.setProperty('--color-primary', theme.colors.primary);
    root.style.setProperty('--color-secondary', theme.colors.secondary);
    root.style.setProperty('--color-accent', theme.colors.accent);
    root.style.setProperty('--color-background', theme.colors.background);
    root.style.setProperty('--color-text', theme.colors.text);
    
    root.style.setProperty('--font-family', theme.fonts.family);
    root.style.setProperty('--font-size', `${theme.fonts.size}px`);
    root.style.setProperty('--line-height', theme.fonts.lineSpacing.toString());
    
    root.style.setProperty('--icon-size', `${theme.components.iconSize}px`);
    
    // Apply background
    if (theme.background.type === 'gradient' || theme.background.type === 'image') {
      document.body.style.background = theme.background.value;
    } else {
      document.body.style.backgroundColor = theme.background.value;
    }
    
    // Apply theme mode class
    document.body.className = `theme-${theme.mode}`;
  };

  const savePreset = (name: string) => {
    const presets = JSON.parse(localStorage.getItem('segna-theme-presets') || '{}');
    presets[name] = theme;
    localStorage.setItem('segna-theme-presets', JSON.stringify(presets));
  };

  const loadPreset = (name: string) => {
    const presets = JSON.parse(localStorage.getItem('segna-theme-presets') || '{}');
    if (presets[name]) {
      setTheme(presets[name]);
    }
  };

  const getPresets = () => {
    const presets = JSON.parse(localStorage.getItem('segna-theme-presets') || '{}');
    return Object.keys(presets);
  };

  return (
    <ThemeContext.Provider value={{
      theme,
      updateTheme,
      resetTheme,
      applyTheme,
      savePreset,
      loadPreset,
      getPresets,
    }}>
      {children}
    </ThemeContext.Provider>
  );
};