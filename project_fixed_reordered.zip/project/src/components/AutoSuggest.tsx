import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, Search } from 'lucide-react';

interface Option {
  id: string;
  label: string;
  value: string;
  meta?: string;
  details?: string;
}

interface AutoSuggestProps {
  options: Option[];
  onSelect: (option: Option) => void;
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
  className?: string;
  disabled?: boolean;
  showIcon?: boolean;
}

const AutoSuggest: React.FC<AutoSuggestProps> = ({
  options,
  onSelect,
  placeholder = 'Search...',
  value = '',
  onChange,
  className = '',
  disabled = false,
  showIcon = true,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [filteredOptions, setFilteredOptions] = useState<Option[]>([]);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (value.trim() === '') {
      setFilteredOptions(options.slice(0, 8));
    } else {
      const filtered = options.filter(option =>
        option.label.toLowerCase().includes(value.toLowerCase()) ||
        (option.meta && option.meta.toLowerCase().includes(value.toLowerCase())) ||
        (option.details && option.details.toLowerCase().includes(value.toLowerCase()))
      ).slice(0, 8);
      setFilteredOptions(filtered);
    }
    setHighlightedIndex(-1);
  }, [value, options]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    onChange?.(newValue);
    setIsOpen(true);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen) {
      if (e.key === 'ArrowDown' || e.key === 'Enter') {
        setIsOpen(true);
        return;
      }
    }

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setHighlightedIndex(prev => 
          prev < filteredOptions.length - 1 ? prev + 1 : 0
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setHighlightedIndex(prev => 
          prev > 0 ? prev - 1 : filteredOptions.length - 1
        );
        break;
      case 'Enter':
        e.preventDefault();
        if (highlightedIndex >= 0 && filteredOptions[highlightedIndex]) {
          handleSelect(filteredOptions[highlightedIndex]);
        }
        break;
      case 'Escape':
        setIsOpen(false);
        setHighlightedIndex(-1);
        inputRef.current?.blur();
        break;
    }
  };

  const handleSelect = (option: Option) => {
    onSelect(option);
    setIsOpen(false);
    setHighlightedIndex(-1);
  };

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={handleInputChange}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          className="w-full px-4 py-3 pr-12 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-all duration-200 disabled:bg-slate-700 disabled:cursor-not-allowed"
        />
        {showIcon && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
            <Search className="w-4 h-4 text-slate-400" />
            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
          </div>
        )}
      </div>

      {isOpen && filteredOptions.length > 0 && (
        <div className="absolute z-50 w-full mt-1 bg-slate-800 border border-slate-600 rounded-lg shadow-xl max-h-64 overflow-y-auto">
          {filteredOptions.map((option, index) => (
            <div
              key={option.id}
              onClick={() => handleSelect(option)}
              className={`px-4 py-3 cursor-pointer transition-all duration-150 border-b border-slate-700 last:border-b-0 ${
                index === highlightedIndex
                  ? 'bg-yellow-400 text-slate-900'
                  : 'hover:bg-slate-700 text-white'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className={`font-medium ${index === highlightedIndex ? 'text-slate-900' : 'text-yellow-400'}`}>
                    {option.label}
                  </div>
                  {(option.meta || option.details) && (
                    <div className={`text-xs mt-1 ${index === highlightedIndex ? 'text-slate-700' : 'text-slate-400'}`}>
                      {option.meta} {option.details && `• ${option.details}`}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {isOpen && filteredOptions.length === 0 && value.trim() !== '' && (
        <div className="absolute z-50 w-full mt-1 bg-slate-800 border border-slate-600 rounded-lg shadow-xl">
          <div className="px-4 py-3 text-slate-400 text-center">
            No results found
          </div>
        </div>
      )}
    </div>
  );
};

export default AutoSuggest;