import React from "react";
import { NavLink, Outlet } from "react-router-dom";

function Layout() {
  return (
    <div className="flex h-screen">
      {/webpages* Sidebar */}
      <aside className="w-64 bg-gray-900 text-white flex flex-col">
        <h1 className="text-2xl font-bold p-4 border-b border-gray-700">
          SEGNA Dashboard
        </h1>
        <nav className="flex-1 p-2 space-y-2">
          <NavLink to="/" className={({ isActive }) =>
              `block px-4 py-2 rounded ${isActive ? "bg-yellow-500 text-black" : "hover:bg-gray-700"}`}>
            Dashboard
          </NavLink>
          <NavLink to="/sales" className={({ isActive }) =>
              `block px-4 py-2 rounded ${isActive ? "bg-yellow-500 text-black" : "hover:bg-gray-700"}`}>
            Sales
          </NavLink>
          <NavLink to="/expenses" className={({ isActive }) =>
              `block px-4 py-2 rounded ${isActive ? "bg-yellow-500 text-black" : "hover:bg-gray-700"}`}>
            Expenses
          </NavLink>
          <NavLink to="/customers" className={({ isActive }) =>
              `block px-4 py-2 rounded ${isActive ? "bg-yellow-500 text-black" : "hover:bg-gray-700"}`}>
            Customers
          </NavLink>
          <NavLink to="/products" className={({ isActive }) =>
              `block px-4 py-2 rounded ${isActive ? "bg-yellow-500 text-black" : "hover:bg-gray-700"}`}>
            Products
          </NavLink>
          <NavLink to="/notifications" className={({ isActive }) =>
              `block px-4 py-2 rounded ${isActive ? "bg-yellow-500 text-black" : "hover:bg-gray-700"}`}>
            Notifications
          </NavLink>
          <NavLink to="/webpages" className={({ isActive }) =>
              `block px-4 py-2 rounded ${isActive ? "bg-yellow-500 text-black" : "hover:bg-gray-700"}`}>
            Webpages
          </NavLink>
          <NavLink to="/gold-silver" className={({ isActive }) =>
              `block px-4 py-2 rounded ${isActive ? "bg-yellow-500 text-black" : "hover:bg-gray-700"}`}>
            Gold & Silver
          </NavLink>
          <NavLink to="/settings" className={({ isActive }) =>
              `block px-4 py-2 rounded ${isActive ? "bg-yellow-500 text-black" : "hover:bg-gray-700"}`}>
            Settings
          </NavLink>
        </nav>
      </aside>

      {/* Main content */}
      <main className="flex-1 bg-gray-100 p-6 overflow-auto">
        <Outlet /> {/* This will render the selected page */}
      </main>
    </div>
  );
}

export default Layout;
