import React, { useState } from 'react';
import { formatDate } from '../utils/dateUtils';
import { Eye, EyeOff } from 'lucide-react';

const Footer: React.FC = () => {
  const [isVisible, setIsVisible] = useState(true);

  return (
    <>
      <div className="fixed bottom-4 right-4 z-40">
        <button
          onClick={() => setIsVisible(!isVisible)}
          className="p-2 bg-slate-800 text-white rounded-lg shadow-lg hover:bg-slate-700 transition-colors duration-200"
          title={isVisible ? 'Hide Footer' : 'Show Footer'}
        >
          {isVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
      </div>
      
      {isVisible && (
        <footer className="bg-slate-900 border-t border-slate-700 py-4 mt-12">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center">
              <p className="text-slate-400 text-sm">
                © {new Date().getFullYear()} Segna Pro. All rights reserved. | Last updated: {formatDate(new Date().toISOString())}
              </p>
            </div>
          </div>
        </footer>
      )}
    </>
  );
};

export default Footer;