import React from 'react';
import { X, Download, Printer } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface PrintPreviewProps {
  saleData: any;
  onClose: () => void;
}

const PrintPreview: React.FC<PrintPreviewProps> = ({ saleData, onClose }) => {
  const { company } = useData();

  const downloadPDF = async () => {
    const element = document.getElementById('invoice-content');
    if (!element) return;

    try {
      const canvas = await html2canvas(element, {
        scale: 2,
        backgroundColor: '#ffffff',
        logging: false
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const pageHeight = 295;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`Invoice_${saleData.ref}.pdf`);
    } catch (error) {
      console.error('PDF generation failed:', error);
    }
  };

  const downloadJPEG = async () => {
    const element = document.getElementById('invoice-content');
    if (!element) return;

    try {
      const canvas = await html2canvas(element, {
        scale: 2,
        backgroundColor: '#ffffff',
        logging: false,
        width: 384, // Thermal printer width
        height: element.scrollHeight
      });
      
      const link = document.createElement('a');
      link.download = `Invoice_${saleData.ref}_Thermal.jpg`;
      link.href = canvas.toDataURL('image/jpeg', 0.9);
      link.click();
    } catch (error) {
      console.error('JPEG generation failed:', error);
    }
  };

  const printInvoice = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Invoice Preview</h2>
          <div className="flex items-center space-x-3">
            <button
              onClick={downloadPDF}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
            >
              <Download className="w-4 h-4 mr-2" />
              PDF (A4)
            </button>
            <button
              onClick={downloadJPEG}
              className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
            >
              <Download className="w-4 h-4 mr-2" />
              JPEG (Thermal)
            </button>
            <button
              onClick={printInvoice}
              className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors duration-200"
            >
              <Printer className="w-4 h-4 mr-2" />
              Print
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Invoice Content */}
        <div id="invoice-content" className="p-8 bg-white text-black">
          {/* Invoice Date at Top */}
          <div className="text-center mb-6">
            <div className="text-lg font-semibold text-gray-600">
              Invoice Date: {new Date(saleData.date).toLocaleDateString()}
            </div>
          </div>

          {/* Company Header */}
          <div className="text-center border-b-2 border-gray-800 pb-6 mb-6">
            <h1 className="text-3xl font-bold text-blue-800 mb-2">{company.name || 'Segna Pro'}</h1>
            {company.address && <p className="text-gray-600">{company.address}</p>}
            <div className="flex justify-center space-x-4 text-sm text-gray-600 mt-2">
              {company.phone && <span>Phone: {company.phone}</span>}
              {company.gst && <span>GST: {company.gst}</span>}
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mt-4">INVOICE</h2>
          </div>

          {/* Invoice Details */}
          <div className="grid grid-cols-2 gap-8 mb-6">
            <div>
              <h3 className="font-bold text-gray-800 mb-2">Bill To:</h3>
              <div className="text-gray-700">
                <p className="font-semibold">{saleData.customerName}</p>
                {saleData.phone && <p>Phone: {saleData.phone}</p>}
              </div>
            </div>
            <div className="text-right">
              <div className="text-gray-700">
                <p><strong>Invoice #:</strong> {saleData.ref}</p>
                <p><strong>Payment Method:</strong> {saleData.payment}</p>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full border-collapse border border-gray-800 mb-6">
            <thead>
              <tr className="bg-gray-100">
                <th className="border border-gray-800 p-3 text-left font-semibold">Item</th>
                <th className="border border-gray-800 p-3 text-center font-semibold">Qty</th>
                <th className="border border-gray-800 p-3 text-right font-semibold">Price</th>
                <th className="border border-gray-800 p-3 text-right font-semibold">Total</th>
              </tr>
            </thead>
            <tbody>
              {saleData.items.map((item: any, index: number) => (
                <tr key={index}>
                  <td className="border border-gray-800 p-3">{item.name}</td>
                  <td className="border border-gray-800 p-3 text-center">{item.qty}</td>
                  <td className="border border-gray-800 p-3 text-right">₹{item.price.toFixed(2)}</td>
                  <td className="border border-gray-800 p-3 text-right">₹{item.total.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totals */}
          <div className="text-right space-y-2">
            <div className="text-lg">
              <strong>Subtotal: ₹{saleData.subtotal.toFixed(2)}</strong>
            </div>
            {saleData.discount > 0 && (
              <div className="text-lg text-red-600">
                <strong>Discount: -₹{saleData.discount.toFixed(2)}</strong>
              </div>
            )}
            <div className="text-xl font-bold border-t-2 border-gray-800 pt-2">
              <strong>Grand Total: ₹{saleData.grandTotal.toFixed(2)}</strong>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-8 pt-6 border-t border-gray-300 text-center text-sm text-gray-600">
            <p>Thank you for your business!</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrintPreview;