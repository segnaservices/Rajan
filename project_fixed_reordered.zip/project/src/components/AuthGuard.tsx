import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Building, Lock, Smartphone } from 'lucide-react';

interface AuthGuardProps {
  children: React.ReactNode;
}

const AuthGuard: React.FC<AuthGuardProps> = ({ children }) => {
  const { isAuthenticated, login, isAuthEnabled } = useAuth();
  const [pin, setPin] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'pin' | 'otp'>('pin');
  const [error, setError] = useState('');

  if (!isAuthEnabled || isAuthenticated) {
    return <>{children}</>;
  }

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (login(pin)) {
      setError('');
    } else {
      setError('Invalid PIN. Please try again.');
      setPin('');
    }
  };

  const simulateOTP = () => {
    // Simulate OTP generation
    const generatedOTP = Math.floor(100000 + Math.random() * 900000).toString();
    console.log('Simulated OTP:', generatedOTP); // In real app, this would be sent via SMS
    setStep('otp');
    
    // Auto-fill OTP for demo purposes
    setTimeout(() => {
      setOtp(generatedOTP);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Building className="w-12 h-12 text-blue-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Segna Pro</h1>
          <p className="text-gray-600">Secure Business Dashboard</p>
        </div>

        {step === 'pin' ? (
          <form onSubmit={handlePinSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Lock className="w-4 h-4 inline mr-1" />
                Enter PIN
              </label>
              <input
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-center text-lg tracking-widest"
                placeholder="••••"
                maxLength={4}
                autoFocus
              />
            </div>

            {error && (
              <div className="text-red-600 text-sm text-center">{error}</div>
            )}

            <div className="space-y-3">
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium"
              >
                Continue
              </button>
              
              <button
                type="button"
                onClick={simulateOTP}
                className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg hover:bg-gray-200 transition-colors duration-200 font-medium flex items-center justify-center"
              >
                <Smartphone className="w-4 h-4 mr-2" />
                Use OTP Instead
              </button>
            </div>

            <div className="text-center text-xs text-gray-500">
              Default PIN: 1234 (Demo)
            </div>
          </form>
        ) : (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Smartphone className="w-4 h-4 inline mr-1" />
                Enter OTP
              </label>
              <input
                type="text"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-center text-lg tracking-widest"
                placeholder="••••••"
                maxLength={6}
                autoFocus
              />
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  if (otp.length === 6) {
                    login('otp-bypass');
                  }
                }}
                className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium"
              >
                Verify OTP
              </button>
              
              <button
                onClick={() => setStep('pin')}
                className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg hover:bg-gray-200 transition-colors duration-200 font-medium"
              >
                Back to PIN
              </button>
            </div>

            <div className="text-center text-xs text-gray-500">
              OTP sent to registered mobile number
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AuthGuard;