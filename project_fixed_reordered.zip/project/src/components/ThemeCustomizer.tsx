import React, { useState } from 'react';
import { X, Save, RotateCcw, Download } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface ThemeCustomizerProps {
  onClose: () => void;
}

const ThemeCustomizer: React.FC<ThemeCustomizerProps> = ({ onClose }) => {
  const { theme, updateTheme, resetTheme, savePreset, getPresets } = useTheme();
  const [presetName, setPresetName] = useState('');
  const [activeTab, setActiveTab] = useState<'colors' | 'fonts' | 'layout' | 'components' | 'background'>('colors');

  const tabs = [
    { id: 'colors', label: 'Colors' },
    { id: 'fonts', label: 'Fonts' },
    { id: 'layout', label: 'Layout' },
    { id: 'components', label: 'Components' },
    { id: 'background', label: 'Background' },
  ];

  const handleSavePreset = () => {
    if (presetName.trim()) {
      savePreset(presetName);
      setPresetName('');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Design & Appearance</h2>
          <div className="flex items-center space-x-3">
            <button
              onClick={resetTheme}
              className="flex items-center px-3 py-2 text-gray-600 hover:text-gray-800 transition-colors"
            >
              <RotateCcw className="w-4 h-4 mr-1" />
              Reset
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex h-[600px]">
          {/* Sidebar */}
          <div className="w-48 bg-gray-50 border-r border-gray-200 p-4">
            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>

            {/* Preset Management */}
            <div className="mt-8 pt-4 border-t border-gray-200">
              <h4 className="text-sm font-medium text-gray-700 mb-3">Presets</h4>
              <div className="space-y-2">
                <input
                  type="text"
                  value={presetName}
                  onChange={(e) => setPresetName(e.target.value)}
                  placeholder="Preset name"
                  className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
                />
                <button
                  onClick={handleSavePreset}
                  className="w-full flex items-center justify-center px-2 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
                >
                  <Save className="w-3 h-3 mr-1" />
                  Save
                </button>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 p-6 overflow-y-auto">
            {activeTab === 'colors' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-gray-900">Color Settings</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Primary Color</label>
                    <input
                      type="color"
                      value={theme.colors.primary}
                      onChange={(e) => updateTheme({ colors: { ...theme.colors, primary: e.target.value } })}
                      className="w-full h-10 rounded border border-gray-300"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Secondary Color</label>
                    <input
                      type="color"
                      value={theme.colors.secondary}
                      onChange={(e) => updateTheme({ colors: { ...theme.colors, secondary: e.target.value } })}
                      className="w-full h-10 rounded border border-gray-300"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Accent Color</label>
                    <input
                      type="color"
                      value={theme.colors.accent}
                      onChange={(e) => updateTheme({ colors: { ...theme.colors, accent: e.target.value } })}
                      className="w-full h-10 rounded border border-gray-300"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Background Color</label>
                    <input
                      type="color"
                      value={theme.colors.background}
                      onChange={(e) => updateTheme({ colors: { ...theme.colors, background: e.target.value } })}
                      className="w-full h-10 rounded border border-gray-300"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Theme Mode</label>
                  <select
                    value={theme.mode}
                    onChange={(e) => updateTheme({ mode: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="light">Light</option>
                    <option value="dark">Dark</option>
                    <option value="auto">Auto</option>
                  </select>
                </div>
              </div>
            )}

            {activeTab === 'fonts' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-gray-900">Font Settings</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Font Family</label>
                  <select
                    value={theme.fonts.family}
                    onChange={(e) => updateTheme({ fonts: { ...theme.fonts, family: e.target.value } })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="Inter, system-ui, sans-serif">Inter</option>
                    <option value="Roboto, sans-serif">Roboto</option>
                    <option value="Open Sans, sans-serif">Open Sans</option>
                    <option value="Lato, sans-serif">Lato</option>
                    <option value="Poppins, sans-serif">Poppins</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Font Size: {theme.fonts.size}px</label>
                  <input
                    type="range"
                    min="12"
                    max="18"
                    value={theme.fonts.size}
                    onChange={(e) => updateTheme({ fonts: { ...theme.fonts, size: parseInt(e.target.value) } })}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Line Spacing: {theme.fonts.lineSpacing}</label>
                  <input
                    type="range"
                    min="1.2"
                    max="2"
                    step="0.1"
                    value={theme.fonts.lineSpacing}
                    onChange={(e) => updateTheme({ fonts: { ...theme.fonts, lineSpacing: parseFloat(e.target.value) } })}
                    className="w-full"
                  />
                </div>
              </div>
            )}

            {activeTab === 'layout' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-gray-900">Layout Settings</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Sidebar Position</label>
                  <select
                    value={theme.layout.sidebar}
                    onChange={(e) => updateTheme({ layout: { ...theme.layout, sidebar: e.target.value as any } })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="left">Left</option>
                    <option value="right">Right</option>
                    <option value="top">Top</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Layout Style</label>
                  <select
                    value={theme.layout.style}
                    onChange={(e) => updateTheme({ layout: { ...theme.layout, style: e.target.value as any } })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="compact">Compact</option>
                    <option value="full">Full</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Card Shape</label>
                  <select
                    value={theme.layout.cardShape}
                    onChange={(e) => updateTheme({ layout: { ...theme.layout, cardShape: e.target.value as any } })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="rounded">Rounded</option>
                    <option value="square">Square</option>
                  </select>
                </div>
              </div>
            )}

            {activeTab === 'components' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-gray-900">Component Settings</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Button Size</label>
                  <select
                    value={theme.components.buttonSize}
                    onChange={(e) => updateTheme({ components: { ...theme.components, buttonSize: e.target.value as any } })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="small">Small</option>
                    <option value="medium">Medium</option>
                    <option value="large">Large</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Button Shape</label>
                  <select
                    value={theme.components.buttonShape}
                    onChange={(e) => updateTheme({ components: { ...theme.components, buttonShape: e.target.value as any } })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="pill">Pill</option>
                    <option value="rounded">Rounded</option>
                    <option value="rectangle">Rectangle</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Icon Size: {theme.components.iconSize}px</label>
                  <input
                    type="range"
                    min="16"
                    max="32"
                    value={theme.components.iconSize}
                    onChange={(e) => updateTheme({ components: { ...theme.components, iconSize: parseInt(e.target.value) } })}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={theme.components.shadows}
                      onChange={(e) => updateTheme({ components: { ...theme.components, shadows: e.target.checked } })}
                      className="rounded"
                    />
                    <span className="text-sm font-medium text-gray-700">Enable Shadows</span>
                  </label>
                </div>
              </div>
            )}

            {activeTab === 'background' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-gray-900">Background Settings</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Background Type</label>
                  <select
                    value={theme.background.type}
                    onChange={(e) => updateTheme({ background: { ...theme.background, type: e.target.value as any } })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="color">Solid Color</option>
                    <option value="gradient">Gradient</option>
                    <option value="pattern">Pattern</option>
                    <option value="image">Image</option>
                  </select>
                </div>
                
                {theme.background.type === 'color' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Background Color</label>
                    <input
                      type="color"
                      value={theme.background.value}
                      onChange={(e) => updateTheme({ background: { ...theme.background, value: e.target.value } })}
                      className="w-full h-10 rounded border border-gray-300"
                    />
                  </div>
                )}
                
                {theme.background.type === 'gradient' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Gradient CSS</label>
                    <textarea
                      value={theme.background.value}
                      onChange={(e) => updateTheme({ background: { ...theme.background, value: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      rows={3}
                      placeholder="linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThemeCustomizer;