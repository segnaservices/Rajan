import React, { useEffect, useRef, useState } from 'react';
import { useData } from '../contexts/DataContext';
import { formatDateTime } from '../utils/dateUtils';
import { TrendingUp, TrendingDown, DollarSign, Calendar, Wallet, Building, AlertCircle, Package, Users } from 'lucide-react';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

const Dashboard: React.FC = () => {
  const { salesEntries, expenses } = useData();
  const [activeTab, setActiveTab] = useState<'today' | 'month' | 'overall'>('today');
  
  // Calculate stats
  const today = new Date().toISOString().slice(0, 10);
  const thisMonth = new Date().toISOString().slice(0, 7);

  // Today's stats
  const todaySales = salesEntries.filter(s => s.date === today).reduce((sum, s) => sum + s.grandTotal, 0);
  const todayExpenses = expenses.filter(e => e.date === today).reduce((sum, e) => sum + e.amount, 0);
  const todayBalance = todaySales - todayExpenses;

  // This month's stats
  const monthSales = salesEntries.filter(s => s.date.startsWith(thisMonth)).reduce((sum, s) => sum + s.grandTotal, 0);
  const monthExpenses = expenses.filter(e => e.date.startsWith(thisMonth)).reduce((sum, e) => sum + e.amount, 0);
  const monthBalance = monthSales - monthExpenses;

  // Overall stats
  const totalSales = salesEntries.reduce((sum, s) => sum + s.grandTotal, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const overallBalance = totalSales - totalExpenses;

  // Cash vs Bank calculations
  const todayCash = salesEntries.filter(s => s.date === today && s.payment === 'Cash').reduce((sum, s) => sum + s.grandTotal, 0) -
                   expenses.filter(e => e.date === today && e.payment === 'Cash').reduce((sum, e) => sum + e.amount, 0);
  const todayBank = salesEntries.filter(s => s.date === today && s.payment !== 'Cash').reduce((sum, s) => sum + s.grandTotal, 0) -
                   expenses.filter(e => e.date === today && e.payment !== 'Cash').reduce((sum, e) => sum + e.amount, 0);

  const monthCash = salesEntries.filter(s => s.date.startsWith(thisMonth) && s.payment === 'Cash').reduce((sum, s) => sum + s.grandTotal, 0) -
                   expenses.filter(e => e.date.startsWith(thisMonth) && e.payment === 'Cash').reduce((sum, e) => sum + e.amount, 0);
  const monthBank = salesEntries.filter(s => s.date.startsWith(thisMonth) && s.payment !== 'Cash').reduce((sum, s) => sum + s.grandTotal, 0) -
                   expenses.filter(e => e.date.startsWith(thisMonth) && e.payment !== 'Cash').reduce((sum, e) => sum + e.amount, 0);

  const overallCash = salesEntries.filter(s => s.payment === 'Cash').reduce((sum, s) => sum + s.grandTotal, 0) -
                     expenses.filter(e => e.payment === 'Cash').reduce((sum, e) => sum + e.amount, 0);
  const overallBank = salesEntries.filter(s => s.payment !== 'Cash').reduce((sum, s) => sum + s.grandTotal, 0) -
                     expenses.filter(e => e.payment !== 'Cash').reduce((sum, e) => sum + e.amount, 0);

  // Calculate pending (not paid) invoices
  const pendingInvoices = salesEntries.filter(sale => sale.status === 'not_paid');
  const pendingAmount = pendingInvoices.reduce((sum, sale) => sum + sale.grandTotal, 0);
  
  // Group pending by customer
  const pendingByCustomer = pendingInvoices.reduce((acc, sale) => {
    if (!acc[sale.customerName]) {
      acc[sale.customerName] = { amount: 0, count: 0, invoices: [] };
    }
    acc[sale.customerName].amount += sale.grandTotal;
    acc[sale.customerName].count += 1;
    acc[sale.customerName].invoices.push(sale);
    return acc;
  }, {} as { [key: string]: { amount: number; count: number; invoices: any[] } });

  // Calculate monthly income by product
  const getMonthlyProductIncome = () => {
    const productIncome: { [key: string]: { amount: number; quantity: number; category: string } } = {};
    const currentMonth = new Date().toISOString().slice(0, 7);
    
    salesEntries
      .filter(sale => sale.date.startsWith(currentMonth))
      .forEach(sale => {
        sale.items.forEach(item => {
          if (!productIncome[item.name]) {
            productIncome[item.name] = { amount: 0, quantity: 0, category: 'General' };
          }
          productIncome[item.name].amount += item.total;
          productIncome[item.name].quantity += item.qty;
        });
      });

    return Object.entries(productIncome)
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.amount - a.amount);
  };

  const monthlyProductIncome = getMonthlyProductIncome();

  const getStats = () => {
    switch (activeTab) {
      case 'today':
        return {
          sales: todaySales,
          expenses: todayExpenses,
          balance: todayBalance,
          cash: todayCash,
          bank: todayBank
        };
      case 'month':
        return {
          sales: monthSales,
          expenses: monthExpenses,
          balance: monthBalance,
          cash: monthCash,
          bank: monthBank
        };
      case 'overall':
        return {
          sales: totalSales,
          expenses: totalExpenses,
          balance: overallBalance,
          cash: overallCash,
          bank: overallBank
        };
      default:
        return {
          sales: 0,
          expenses: 0,
          balance: 0,
          cash: 0,
          bank: 0
        };
    }
  };

  const stats = getStats();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white">📊 Business Dashboard</h2>
          <p className="text-slate-300">Real-time business analytics and insights</p>
        </div>
        <div className="text-sm text-slate-400">
          Last updated: {formatDateTime(new Date().toISOString())}
        </div>
      </div>

      {/* Time Period Tabs */}
      <div className="flex space-x-1 bg-slate-800 p-1 rounded-lg border border-slate-600">
        {[
          { key: 'today', label: 'Today', icon: Calendar },
          { key: 'month', label: 'This Month', icon: Calendar },
          { key: 'overall', label: 'Overall', icon: Building }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              className={`flex-1 flex items-center justify-center px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                activeTab === tab.key
                  ? 'bg-yellow-500 text-slate-900'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              <Icon className="w-4 h-4 mr-2" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        {/* Sales */}
        <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100">Sales</p>
              <p className="text-2xl font-bold">₹{stats.sales.toLocaleString()}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-green-200" />
          </div>
        </div>

        {/* Expenses */}
        <div className="bg-gradient-to-br from-red-600 to-red-700 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-100">Expenses</p>
              <p className="text-2xl font-bold">₹{stats.expenses.toLocaleString()}</p>
            </div>
            <TrendingDown className="w-8 h-8 text-red-200" />
          </div>
        </div>

        {/* Net Balance */}
        <div className={`bg-gradient-to-br ${stats.balance >= 0 ? 'from-blue-600 to-blue-700' : 'from-orange-600 to-orange-700'} rounded-xl p-6 text-white shadow-lg`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={stats.balance >= 0 ? 'text-blue-100' : 'text-orange-100'}>Net {stats.balance >= 0 ? 'Profit' : 'Loss'}</p>
              <p className="text-2xl font-bold">₹{Math.abs(stats.balance).toLocaleString()}</p>
            </div>
            <DollarSign className={`w-8 h-8 ${stats.balance >= 0 ? 'text-blue-200' : 'text-orange-200'}`} />
          </div>
        </div>

        {/* Cash in Hand */}
        <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100">Cash in Hand</p>
              <p className="text-2xl font-bold">₹{stats.cash.toLocaleString()}</p>
            </div>
            <Wallet className="w-8 h-8 text-purple-200" />
          </div>
        </div>

        {/* Cash at Bank */}
        <div className="bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-indigo-100">Cash at Bank</p>
              <p className="text-2xl font-bold">₹{stats.bank.toLocaleString()}</p>
            </div>
            <Building className="w-8 h-8 text-indigo-200" />
          </div>
        </div>
      </div>

      {/* Monthly Income by Product Table */}
      <div className="bg-gradient-to-br from-slate-800 via-slate-700 to-slate-800 rounded-2xl border-2 border-slate-600 shadow-2xl overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 border-b-2 border-blue-500">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-white bg-opacity-20 rounded-lg">
                <Package className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white">Monthly Income by Product</h3>
                <p className="text-blue-100 text-sm">{new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</p>
              </div>
            </div>
            <div className="bg-white bg-opacity-20 px-4 py-2 rounded-full">
              <span className="text-white font-semibold">{monthlyProductIncome.length} Products</span>
            </div>
          </div>
        </div>
        
        {monthlyProductIncome.length > 0 ? (
          <div className="p-6">
            <div className="overflow-hidden rounded-xl border border-slate-600">
              <table className="w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-slate-700 to-slate-600">
                    <th className="px-6 py-4 text-left text-sm font-bold text-yellow-400 uppercase tracking-wider">
                      <div className="flex items-center space-x-2">
                        <span>#</span>
                        <span>Product / Service</span>
                      </div>
                    </th>
                    <th className="px-6 py-4 text-center text-sm font-bold text-yellow-400 uppercase tracking-wider">Quantity</th>
                    <th className="px-6 py-4 text-center text-sm font-bold text-yellow-400 uppercase tracking-wider">Avg Price</th>
                    <th className="px-6 py-4 text-right text-sm font-bold text-yellow-400 uppercase tracking-wider">Total Income</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700">
                  {monthlyProductIncome.map((product, index) => {
                    const isTop3 = index < 3;
                    const avgPrice = product.amount / product.quantity;
                    
                    return (
                      <tr 
                        key={product.name} 
                        className={`hover:bg-gradient-to-r hover:from-slate-700 hover:to-slate-600 transition-all duration-300 transform hover:scale-[1.02] ${
                          isTop3 ? 'bg-gradient-to-r from-green-900/20 to-blue-900/20' : ''
                        }`}
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-3">
                            <div className={`flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm ${
                              index === 0 ? 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-yellow-900' :
                              index === 1 ? 'bg-gradient-to-r from-gray-300 to-gray-500 text-gray-900' :
                              index === 2 ? 'bg-gradient-to-r from-orange-400 to-orange-600 text-orange-900' :
                              'bg-gradient-to-r from-slate-600 to-slate-700 text-white'
                            }`}>
                              {index + 1}
                            </div>
                            <div>
                              <div className="text-white font-semibold">{product.name}</div>
                              <div className="text-slate-400 text-xs">{product.category}</div>
                            </div>
                            {isTop3 && (
                              <div className="flex items-center space-x-1">
                                <TrendingUp className="w-4 h-4 text-green-400" />
                                <span className="text-xs text-green-400 font-medium">Top Performer</span>
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-600 text-white">
                            {product.quantity}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span className="text-slate-300 font-medium">₹{avgPrice.toFixed(2)}</span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <DollarSign className="w-4 h-4 text-green-400" />
                            <span className="text-green-400 font-bold text-lg">₹{product.amount.toLocaleString()}</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="p-12 text-center">
            <Package className="mx-auto h-16 w-16 text-slate-400 mb-4" />
            <h4 className="text-lg font-medium text-white mb-2">No Sales Data</h4>
            <p className="text-slate-400">No product sales recorded for this month</p>
          </div>
        )}
      </div>

      {/* Not Paid Customer Amounts */}
      {Object.keys(pendingByCustomer).length > 0 && (
        <div className="bg-gradient-to-br from-red-900 via-red-800 to-red-900 rounded-2xl border-2 border-red-600 shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-red-600 to-orange-600 p-6 border-b-2 border-red-500">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-white bg-opacity-20 rounded-lg">
                  <AlertCircle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Not Paid Customer Amounts</h3>
                  <p className="text-red-100 text-sm">Outstanding payments requiring attention</p>
                </div>
              </div>
              <div className="bg-white bg-opacity-20 px-4 py-2 rounded-full">
                <span className="text-white font-semibold">₹{pendingAmount.toLocaleString()}</span>
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <div className="overflow-hidden rounded-xl border border-red-600">
              <table className="w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-red-700 to-red-600">
                    <th className="px-6 py-4 text-left text-sm font-bold text-yellow-400 uppercase tracking-wider">
                      <div className="flex items-center space-x-2">
                        <Users className="w-4 h-4" />
                        <span>Customer Name</span>
                      </div>
                    </th>
                    <th className="px-6 py-4 text-center text-sm font-bold text-yellow-400 uppercase tracking-wider">Invoices</th>
                    <th className="px-6 py-4 text-center text-sm font-bold text-yellow-400 uppercase tracking-wider">Days Overdue</th>
                    <th className="px-6 py-4 text-right text-sm font-bold text-yellow-400 uppercase tracking-wider">Outstanding Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-red-700">
                  {Object.entries(pendingByCustomer).map(([customer, data]) => {
                    const oldestInvoice = data.invoices.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0];
                    const daysOverdue = Math.floor((new Date().getTime() - new Date(oldestInvoice.date).getTime()) / (1000 * 60 * 60 * 24));
                    const isHighPriority = data.amount > 10000 || daysOverdue > 30;
                    
                    return (
                      <tr 
                        key={customer} 
                        className={`hover:bg-gradient-to-r hover:from-red-800 hover:to-red-700 transition-all duration-300 transform hover:scale-[1.02] ${
                          isHighPriority ? 'bg-gradient-to-r from-red-800/30 to-orange-800/30' : ''
                        }`}
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-3">
                            <div className={`w-3 h-3 rounded-full ${
                              isHighPriority ? 'bg-red-400 animate-pulse' : 'bg-yellow-400'
                            }`}></div>
                            <div>
                              <div className="text-white font-semibold">{customer}</div>
                              <div className="text-red-200 text-xs">Last invoice: {oldestInvoice.date}</div>
                            </div>
                            {isHighPriority && (
                              <div className="flex items-center space-x-1">
                                <AlertCircle className="w-4 h-4 text-red-400" />
                                <span className="text-xs text-red-400 font-medium">High Priority</span>
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-orange-600 text-white">
                            {data.count}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                            daysOverdue > 30 ? 'bg-red-600 text-white' :
                            daysOverdue > 15 ? 'bg-orange-600 text-white' :
                            'bg-yellow-600 text-white'
                          }`}>
                            {daysOverdue} days
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <DollarSign className="w-4 h-4 text-red-400" />
                            <span className="text-red-400 font-bold text-lg">₹{data.amount.toLocaleString()}</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;