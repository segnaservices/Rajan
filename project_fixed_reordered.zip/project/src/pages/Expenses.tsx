import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { useError } from '../contexts/ErrorContext';
import { usePopup } from '../contexts/PopupContext';
import ActionDropdown from '../components/ActionDropdown';
import { formatDateTime, formatDate } from '../utils/dateUtils';
import { Plus, Search, CreditCard, Edit, Trash2, Download, Upload, Calendar, DollarSign } from 'lucide-react';

const Expenses: React.FC = () => {
  const { expenses, addExpense, updateExpense, deleteExpense, generateRef, exportToExcel, importFromExcel } = useData();
  const { showError } = useError();
  const { confirm } = usePopup();
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState({
    date: new Date().toISOString().slice(0, 10),
    ref: '',
    description: '',
    note: '',
    category: '',
    amount: '',
    payment: 'Cash',
  });

  const filteredExpenses = expenses
    .filter(expense =>
      expense.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      expense.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      expense.ref.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()); // Latest first

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.description.trim() || !formData.amount) {
      showError('Description and amount are required');
      return;
    }

    try {
      const expenseData = {
        type: 'Expense' as const,
        date: formData.date,
        ref: formData.ref || generateRef('EXP'),
        description: formData.description,
        note: formData.note,
        category: formData.category || 'General',
        amount: parseFloat(formData.amount),
        payment: formData.payment,
      };

      if (editingId) {
        updateExpense(editingId, expenseData);
      } else {
        addExpense(expenseData);
      }
      
      setFormData({
        date: new Date().toISOString().slice(0, 10),
        ref: '',
        description: '',
        note: '',
        category: '',
        amount: '',
        payment: 'Cash',
      });
      setEditingId(null);
      setIsModalOpen(false);
    } catch (error) {
      showError('Failed to save expense');
    }
  };

  const handleEdit = (expense: any) => {
    setFormData({
      date: expense.date,
      ref: expense.ref,
      description: expense.description,
      note: expense.note || '',
      category: expense.category,
      amount: expense.amount.toString(),
      payment: expense.payment,
    });
    setEditingId(expense.id);
    setIsModalOpen(true);
  };

  const handleDelete = (id: string, description: string) => {
    confirm(
      `Are you sure you want to delete "${description}"?`,
      () => deleteExpense(id),
      {
        title: 'Delete Expense',
        showDontAskAgain: true,
        skipKey: 'deleteExpense'
      }
    );
  };

  const handleExport = () => {
    exportToExcel('expenses');
  };

  const handleImport = (file: File) => {
    importFromExcel(file, 'expenses');
  };

  const totalExpenses = filteredExpenses.reduce((sum, expense) => sum + expense.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white">💸 Expense Management</h2>
          <p className="text-slate-300">Track and manage your business expenses</p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={handleExport}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
          >
            <Download className="w-4 h-4 mr-2" />
            Export Excel
          </button>
          <label className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 cursor-pointer">
            <Upload className="w-4 h-4 mr-2" />
            Import Excel
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={(e) => e.target.files?.[0] && handleImport(e.target.files[0])}
              className="hidden"
            />
          </label>
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center px-4 py-2 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Expense
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-red-600 to-red-700 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-100">Total Expenses</p>
              <p className="text-2xl font-bold">₹{totalExpenses.toLocaleString()}</p>
            </div>
            <CreditCard className="w-8 h-8 text-red-200" />
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100">This Month</p>
              <p className="text-2xl font-bold">
                ₹{expenses.filter(e => e.date.startsWith(new Date().toISOString().slice(0, 7)))
                  .reduce((sum, e) => sum + e.amount, 0).toLocaleString()}
              </p>
            </div>
            <Calendar className="w-8 h-8 text-purple-200" />
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-orange-600 to-orange-700 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100">Categories</p>
              <p className="text-2xl font-bold">{[...new Set(expenses.map(e => e.category))].length}</p>
            </div>
            <DollarSign className="w-8 h-8 text-orange-200" />
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
        <input
          type="text"
          placeholder="Search expenses..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
        />
      </div>

      {/* Expenses Table */}
      <div className="bg-slate-800 rounded-xl border border-slate-600 overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-blue-800">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Date</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Reference</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Description</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Category</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Amount</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Payment</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {filteredExpenses.map((expense) => {
                const actions = [
                  {
                    label: 'Edit',
                    icon: <Edit className="w-4 h-4" />,
                    action: () => handleEdit(expense),
                    variant: 'default' as const
                  },
                  {
                    label: 'Delete',
                    icon: <Trash2 className="w-4 h-4" />,
                    action: () => handleDelete(expense.id, expense.description),
                    variant: 'danger' as const
                  }
                ];

                return (
                  <tr key={expense.id} className="hover:bg-slate-700 transition-colors">
                    <td className="px-6 py-4 text-sm text-white">{formatDate(expense.date)}</td>
                    <td className="px-6 py-4 text-sm text-white">
                      <span className="font-mono text-blue-400">{expense.ref}</span>
                    </td>
                    <td className="px-6 py-4 text-sm text-white">
                      <div>{expense.description}</div>
                      {expense.note && <div className="text-xs text-slate-400 mt-1">{expense.note}</div>}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span className="px-2 py-1 bg-purple-600 text-white rounded-full text-xs">
                        {expense.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-red-400">
                      ₹{expense.amount.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-sm text-white">{expense.payment}</td>
                    <td className="px-6 py-4 text-sm">
                      <ActionDropdown actions={actions} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredExpenses.length === 0 && (
          <div className="text-center py-12">
            <CreditCard className="mx-auto h-12 w-12 text-slate-400" />
            <h3 className="mt-2 text-sm font-medium text-white">No expenses found</h3>
            <p className="mt-1 text-sm text-slate-400">
              {searchQuery ? 'Try adjusting your search criteria' : 'Get started by adding your first expense'}
            </p>
          </div>
        )}
      </div>

      {/* Add/Edit Expense Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-lg shadow-xl max-w-md w-full border border-slate-600">
            <div className="p-6 border-b border-slate-600">
              <h3 className="text-lg font-semibold text-white">
                {editingId ? 'Edit Expense' : 'Add New Expense'}
              </h3>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Date *
                  </label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Reference
                  </label>
                  <input
                    type="text"
                    value={formData.ref}
                    onChange={(e) => setFormData(prev => ({ ...prev, ref: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                    placeholder="Auto-generated if empty"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Description *
                </label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Note
                </label>
                <textarea
                  value={formData.note}
                  onChange={(e) => setFormData(prev => ({ ...prev, note: e.target.value }))}
                  rows={2}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                  placeholder="Additional notes (optional)"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Category
                  </label>
                  <input
                    type="text"
                    value={formData.category}
                    onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                    placeholder="General"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Amount *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.amount}
                    onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Payment Method
                </label>
                <select
                  value={formData.payment}
                  onChange={(e) => setFormData(prev => ({ ...prev, payment: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                >
                  <option value="Cash">Cash</option>
                  <option value="UPI">UPI</option>
                  <option value="Card">Card</option>
                  <option value="Bank Transfer">Bank Transfer</option>
                  <option value="Cheque">Cheque</option>
                </select>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingId(null);
                    setFormData({
                      date: new Date().toISOString().slice(0, 10),
                      ref: '',
                      description: '',
                      note: '',
                      category: '',
                      amount: '',
                      payment: 'Cash',
                    });
                  }}
                  className="px-4 py-2 border border-slate-600 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors duration-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium"
                >
                  {editingId ? 'Update' : 'Add'} Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Expenses;