import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { useError } from '../contexts/ErrorContext';
import { usePopup } from '../contexts/PopupContext';
import ActionDropdown from '../components/ActionDropdown';
import { formatDate } from '../utils/dateUtils';
import { Plus, Search, Package, Wrench, Edit, Trash2 } from 'lucide-react';

const Products: React.FC = () => {
  const { products, addProduct, updateProduct, deleteProduct } = useData();
  const { showError } = useError();
  const { confirm } = usePopup();
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'products' | 'services'>('products');
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    category: '',
    stock: '',
    description: '',
    type: 'product' as 'product' | 'service',
  });

  const filteredProducts = products
    .filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           product.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      // Fix tab filtering logic
      let matchesTab = false;
      if (activeTab === 'products') {
        matchesTab = product.type === 'product' || product.type === undefined || product.type === null;
      } else if (activeTab === 'services') {
        matchesTab = product.type === 'service';
      }
      
      console.log('Product:', product.name, 'Type:', product.type, 'ActiveTab:', activeTab, 'MatchesTab:', matchesTab);
      return matchesSearch && matchesTab;
    })
    .sort((a, b) => {
      const dateA = new Date(a.createdAt || 0).getTime();
      const dateB = new Date(b.createdAt || 0).getTime();
      return dateB - dateA;
    });

  // Enhanced debug logging
  console.log('=== PRODUCTS DEBUG ===');
  console.log('Active tab:', activeTab);
  console.log('Total products in database:', products.length);
  console.log('All products:', products.map(p => ({ name: p.name, type: p.type })));
  console.log('Filtered products count:', filteredProducts.length);
  console.log('Filtered products:', filteredProducts.map(p => ({ name: p.name, type: p.type })));
  console.log('======================');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.price || !formData.category.trim()) {
      showError('Name, price, and category are required');
      return;
    }

    try {
      const productData = {
        name: formData.name,
        price: parseFloat(formData.price),
        category: formData.category,
        stock: activeTab === 'products' ? parseInt(formData.stock) || 0 : 0,
        description: formData.description,
        type: activeTab === 'products' ? 'product' as const : 'service' as const,
      };

      console.log('Submitting product data:', productData);
      console.log('Active tab:', activeTab);
      
      if (editingId) {
        updateProduct(editingId, productData);
      } else {
        addProduct(productData);
      }
      
      setFormData({ 
        name: '', 
        price: '', 
        category: '', 
        stock: '', 
        description: '', 
        type: activeTab === 'products' ? 'product' : 'service'
      });
      setEditingId(null);
      setIsModalOpen(false);
    } catch (error) {
      showError(`Failed to save ${activeTab.slice(0, -1)}`);
    }
  };

  const handleEdit = (product: any) => {
    setFormData({
      name: product.name,
      price: product.price.toString(),
      category: product.category,
      stock: product.stock.toString(),
      description: product.description,
      type: product.type,
    });
    setEditingId(product.id);
    setActiveTab(product.type);
    setIsModalOpen(true);
  };

  const handleDelete = (id: string, name: string) => {
    confirm(
      `Are you sure you want to delete "${name}"?`,
      () => deleteProduct(id),
      {
        title: 'Delete Product',
        showDontAskAgain: true,
        skipKey: 'deleteProduct'
      }
    );
  };

  const getStockStatus = (stock: number) => {
    if (stock === 0) return { text: 'Out of Stock', color: 'bg-red-100 text-red-800' };
    if (stock < 10) return { text: 'Low Stock', color: 'bg-yellow-100 text-yellow-800' };
    return { text: 'In Stock', color: 'bg-green-100 text-green-800' };
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white">📦 Product Catalogue</h2>
          <p className="text-slate-300">Manage your products and services inventory</p>
        </div>
        <button
          onClick={() => {
            setFormData({ 
              name: '', 
              price: '', 
              category: '', 
              stock: '', 
              description: '', 
              type: activeTab as 'product' | 'service'
            });
            setEditingId(null);
            setIsModalOpen(true);
          }}
          className="flex items-center px-4 py-2 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add {activeTab === 'products' ? 'Product' : 'Service'}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-slate-800 p-1 rounded-lg border border-slate-600">
        <button
          onClick={() => setActiveTab('products')}
          className={`flex-1 flex items-center justify-center px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
            activeTab === 'products'
              ? 'bg-yellow-500 text-slate-900'
              : 'text-slate-300 hover:text-white hover:bg-slate-700'
          }`}
        >
          <Package className="w-4 h-4 mr-2" />
          Products
        </button>
        <button
          onClick={() => setActiveTab('services')}
          className={`flex-1 flex items-center justify-center px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
            activeTab === 'services'
              ? 'bg-yellow-500 text-slate-900'
              : 'text-slate-300 hover:text-white hover:bg-slate-700'
          }`}
        >
          <Wrench className="w-4 h-4 mr-2" />
          Services
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
        <input
          type="text"
          placeholder={`Search ${activeTab}...`}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
        />
      </div>

      {/* Products Grid */}
      <div className="mb-4">
        <p className="text-sm text-slate-400">
          Showing {filteredProducts.length} {activeTab} | 
          Total in database: {products.length} | 
          Products: {products.filter(p => p.type === 'product' || !p.type).length} | 
          Services: {products.filter(p => p.type === 'service').length}
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map((product) => {
          const stockStatus = activeTab === 'products' ? getStockStatus(product.stock) : null;
          
          const actions = [
            {
              label: 'Edit',
              icon: <Edit className="w-4 h-4" />,
              action: () => handleEdit(product),
              variant: 'default' as const
            },
            {
              label: 'Delete',
              icon: <Trash2 className="w-4 h-4" />,
              action: () => handleDelete(product.id, product.name),
              variant: 'danger' as const
            }
          ];

          return (
            <div key={product.id} className="group bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 border border-slate-600 hover:border-yellow-400 transition-all duration-200 hover:transform hover:-translate-y-1 shadow-lg">
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-white">{product.name}</h3>
                    <p className="text-sm text-slate-400 mt-1">{product.ref} • {product.category}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {stockStatus && (
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${stockStatus.color}`}>
                        {stockStatus.text}
                      </span>
                    )}
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                      <ActionDropdown actions={actions} />
                    </div>
                  </div>
                </div>
                
                <p className="text-sm text-slate-300">{product.description}</p>
                
                <div className="flex items-center justify-between pt-3 border-t border-slate-700">
                  <div className="flex items-center text-lg font-bold text-yellow-400">
                    ₹{product.price.toLocaleString()}
                  </div>
                  {activeTab === 'products' && (
                    <div className="flex items-center text-sm text-slate-400">
                      <Package className="w-4 h-4 mr-1" />
                      {product.stock} in stock
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          {activeTab === 'products' ? <Package className="mx-auto h-12 w-12 text-slate-400" /> : <Wrench className="mx-auto h-12 w-12 text-slate-400" />}
          <h3 className="mt-2 text-sm font-medium text-white">No {activeTab} found</h3>
          <p className="mt-1 text-sm text-slate-400">
            {searchQuery ? 'Try adjusting your search criteria' : `Get started by adding your first ${activeTab.slice(0, -1)}`}
          </p>
        </div>
      )}

      {/* Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-lg shadow-xl max-w-md w-full border border-slate-600">
            <div className="p-6 border-b border-slate-600">
              <h3 className="text-lg font-semibold text-white">
                {editingId ? `Edit ${activeTab.slice(0, -1)}` : `Add New ${activeTab.slice(0, -1)}`}
              </h3>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  {activeTab === 'products' ? 'Product' : 'Service'} Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Price *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.price}
                    onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                    required
                  />
                </div>

                {activeTab === 'products' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Stock Quantity
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={formData.stock}
                      onChange={(e) => setFormData(prev => ({ ...prev, stock: e.target.value }))}
                      className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Category *
                </label>
                <input
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingId(null);
                    setFormData({ 
                      name: '', 
                      price: '', 
                      category: '', 
                      stock: '', 
                      description: '', 
                      type: activeTab as 'product' | 'service'
                    });
                  }}
                  className="px-4 py-2 border border-slate-600 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors duration-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium"
                >
                  {editingId ? 'Update' : 'Add'} {activeTab.slice(0, -1)}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Products;