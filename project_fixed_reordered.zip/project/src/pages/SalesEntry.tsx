import React, { useState, useCallback } from 'react';
import { useData, Customer, Product, SalesItem } from '../contexts/DataContext';
import { useError } from '../contexts/ErrorContext';
import { usePopup } from '../contexts/PopupContext';
import AutoSuggest from '../components/AutoSuggest';
import ActionDropdown from '../components/ActionDropdown';
import { formatDateTime, formatDate } from '../utils/dateUtils';
import { Plus, Trash2, Save, Calculator, ShoppingCart, User, Phone, CreditCard, FileText, ChevronDown, ChevronUp, DollarSign, X } from 'lucide-react';

const SalesEntry: React.FC = () => {
  const { customers, products, salesEntries, addSalesEntry, deleteSalesEntry, searchCustomers, searchProducts, generateRef } = useData();
  const { showError } = useError();
  const { confirm } = usePopup();
  
  const [showSalesModal, setShowSalesModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [customerQuery, setCustomerQuery] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [invoiceRef, setInvoiceRef] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [salesItems, setSalesItems] = useState<SalesItem[]>([]);
  const [discount, setDiscount] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showCustomerDetails, setShowCustomerDetails] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'paid' | 'not_paid'>('paid');

  // Product search state
  const [productQueries, setProductQueries] = useState<{ [key: number]: string }>({});

  const customerOptions = searchCustomers(customerQuery).map(customer => ({
    id: customer.id,
    label: customer.name,
    value: customer.name,
    meta: customer.company,
    details: customer.phone,
  }));

  const getProductOptions = useCallback((query: string) => {
    return searchProducts(query).map(product => ({
      id: product.id,
      label: product.name,
      value: product.name,
      meta: `₹${product.price}`,
      details: product.type === 'product' ? `${product.stock} in stock` : 'Service',
    }));
  }, [searchProducts]);

  const handleCustomerSelect = (option: { id: string; label: string; value: string; details?: string }) => {
    const customer = customers.find(c => c.id === option.id);
    if (customer) {
      setSelectedCustomer(customer);
      setCustomerQuery(customer.name);
      setPhoneNumber(customer.phone);
    }
  };

  const addSalesItem = () => {
    setSalesItems(prev => [...prev, {
      productId: '',
      name: '',
      qty: 1,
      price: 0,
      total: 0
    }]);
  };

  const updateSalesItem = (index: number, field: keyof SalesItem, value: any) => {
    setSalesItems(prev => prev.map((item, i) => {
      if (i === index) {
        const updated = { ...item, [field]: value };
        if (field === 'qty' || field === 'price') {
          updated.total = updated.qty * updated.price;
        }
        return updated;
      }
      return item;
    }));
  };

  const handleProductSelect = (itemIndex: number, option: { id: string; label: string; value: string; meta?: string }) => {
    const product = products.find(p => p.id === option.id);
    if (product) {
      updateSalesItem(itemIndex, 'productId', product.id);
      updateSalesItem(itemIndex, 'name', product.name);
      updateSalesItem(itemIndex, 'price', product.price);
      setProductQueries(prev => ({ ...prev, [itemIndex]: product.name }));
    }
  };

  const removeSalesItem = (index: number) => {
    confirm(
      'Are you sure you want to remove this item?',
      () => {
        setSalesItems(prev => prev.filter((_, i) => i !== index));
        setProductQueries(prev => {
          const newQueries = { ...prev };
          delete newQueries[index];
          return newQueries;
        });
      },
      {
        title: 'Remove Item',
        showDontAskAgain: true,
        skipKey: 'removeSaleItem'
      }
    );
  };

  const calculateSubtotal = () => {
    return salesItems.reduce((sum, item) => sum + item.total, 0);
  };

  const calculateGrandTotal = () => {
    return calculateSubtotal() - discount;
  };

  const resetForm = () => {
    const resetAction = () => {
      setSelectedCustomer(null);
      setCustomerQuery('');
      setPhoneNumber('');
      setInvoiceRef('');
      setSalesItems([]);
      setDiscount(0);
      setProductQueries({});
      setShowCustomerDetails(false);
      setPaymentStatus('paid');
    };

    if (salesItems.length > 0 || customerQuery || phoneNumber) {
      confirm(
        'This will clear all entered data. Are you sure?',
        resetAction,
        {
          title: 'Reset Form',
          showDontAskAgain: true,
          skipKey: 'resetSalesForm'
      });
    } else {
      resetAction();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      if (salesItems.length === 0) {
        throw new Error('Please add at least one item');
      }

      if (!customerQuery.trim()) {
        throw new Error('Please select or enter a customer name');
      }

      if (!paymentMethod) {
        throw new Error('Please select a payment method');
      }

      const saleData = {
        type: 'Sale' as const,
        date: new Date().toISOString(),
        ref: invoiceRef || generateRef('INV'),
        customerId: selectedCustomer?.id || '',
        customerName: customerQuery,
        phone: phoneNumber,
        payment: paymentMethod,
        items: salesItems,
        subtotal: calculateSubtotal(),
        discount: discount,
        grandTotal: calculateGrandTotal(),
        status: paymentStatus,
      };

      addSalesEntry(saleData);

      resetForm();
      setShowSalesModal(false);
      showError('Sale saved successfully!', 'info');
    } catch (error) {
      showError(error instanceof Error ? error.message : 'Failed to save sale');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white">💰 Sales Entry</h2>
          <p className="text-slate-300">Manage sales transactions with intelligent auto-suggestions</p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setShowSalesModal(true);
          }}
          className="flex items-center px-6 py-3 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium shadow-lg"
        >
          <Plus className="w-5 h-5 mr-2" />
          New Sale
        </button>
      </div>

      {/* Sales Modal */}
      {showSalesModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-gradient-to-br from-blue-700 to-blue-800 rounded-xl border border-indigo-600 shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-indigo-600">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-white">💰 New Sales Entry</h3>
                <button
                  onClick={() => setShowSalesModal(false)}
                  className="p-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              {/* Customer Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-200 mb-2">
                    <User className="w-4 h-4 inline mr-1" />
                    Customer *
                  </label>
                  <AutoSuggest
                    options={customerOptions}
                    onSelect={handleCustomerSelect}
                    placeholder="Search customers..."
                    value={customerQuery}
                    onChange={setCustomerQuery}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-200 mb-2">
                    <FileText className="w-4 h-4 inline mr-1" />
                    Invoice Reference
                  </label>
                  <input
                    type="text"
                    value={invoiceRef}
                    onChange={(e) => setInvoiceRef(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                    placeholder="Auto-generated if empty"
                  />
                </div>
              </div>

              {/* Customer Details Toggle */}
              <div>
                <button
                  type="button"
                  onClick={() => setShowCustomerDetails(!showCustomerDetails)}
                  className="flex items-center text-slate-200 hover:text-white transition-colors duration-200"
                >
                  {showCustomerDetails ? <ChevronUp className="w-4 h-4 mr-1" /> : <ChevronDown className="w-4 h-4 mr-1" />}
                  Customer Details {showCustomerDetails ? '(Hide)' : '(Show)'}
                </button>
                
                {showCustomerDetails && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 p-4 bg-slate-800 rounded-lg border border-slate-600">
                    <div>
                      <label className="block text-sm font-medium text-slate-200 mb-2">
                        <Phone className="w-4 h-4 inline mr-1" />
                        Phone Number
                      </label>
                      <input
                        type="text"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                        placeholder="Customer phone"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Payment Method & Status */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-200 mb-2">
                    <CreditCard className="w-4 h-4 inline mr-1" />
                    Payment Method *
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 appearance-none cursor-pointer"
                    required
                  >
                    <option value="">Select Payment Method</option>
                    <option value="Cash">💵 Cash</option>
                    <option value="UPI">📱 UPI</option>
                    <option value="Card">💳 Card</option>
                    <option value="Bank Transfer">🏦 Bank Transfer</option>
                    <option value="Cheque">📄 Cheque</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-200 mb-2">
                    <DollarSign className="w-4 h-4 inline mr-1" />
                    Payment Status *
                  </label>
                  <select
                    value={paymentStatus}
                    onChange={(e) => setPaymentStatus(e.target.value as 'paid' | 'not_paid')}
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 appearance-none cursor-pointer"
                    required
                  >
                    <option value="">Select Payment Status</option>
                    <option value="paid">✅ Paid</option>
                    <option value="not_paid">❌ Not Paid</option>
                  </select>
                </div>
              </div>

              {/* Sales Items */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-yellow-400">Sales Items</h3>
                  <button
                    type="button"
                    onClick={addSalesItem}
                    className="flex items-center px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Add Item
                  </button>
                </div>

                <div className="bg-slate-800 border border-slate-600 rounded-lg overflow-hidden">
                  {/* Table Header */}
                  <div className="bg-slate-700 px-4 py-3 border-b border-slate-600">
                    <div className="grid grid-cols-12 gap-4 text-xs font-medium text-slate-300 uppercase tracking-wider">
                      <div className="col-span-5">Product/Service</div>
                      <div className="col-span-2 text-center">Quantity</div>
                      <div className="col-span-2 text-center">Unit Price</div>
                      <div className="col-span-2 text-center">Total</div>
                      <div className="col-span-1 text-center">Action</div>
                    </div>
                  </div>

                  {/* Table Body */}
                  <div className="max-h-60 overflow-y-auto">
                    {salesItems.map((item, index) => (
                      <div key={index} className="px-4 py-3 border-b border-slate-700 last:border-b-0 hover:bg-slate-700 transition-colors duration-200">
                        <div className="grid grid-cols-12 gap-4 items-center">
                          <div className="col-span-5">
                            <AutoSuggest
                              options={getProductOptions(productQueries[index] || '')}
                              onSelect={(option) => handleProductSelect(index, option)}
                              placeholder="Search products..."
                              value={productQueries[index] || item.name}
                              onChange={(value) => {
                                setProductQueries(prev => ({ ...prev, [index]: value }));
                                updateSalesItem(index, 'name', value);
                              }}
                            />
                          </div>

                          <div className="col-span-2">
                            <input
                              type="number"
                              min="1"
                              value={item.qty}
                              onChange={(e) => updateSalesItem(index, 'qty', parseInt(e.target.value) || 1)}
                              className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white text-center focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                            />
                          </div>

                          <div className="col-span-2">
                            <input
                              type="number"
                              step="0.01"
                              min="0"
                              value={item.price}
                              onChange={(e) => updateSalesItem(index, 'price', parseFloat(e.target.value) || 0)}
                              className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white text-center focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                            />
                          </div>

                          <div className="col-span-2">
                            <div className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-green-400 font-semibold text-center">
                              ₹{item.total.toFixed(2)}
                            </div>
                          </div>

                          <div className="col-span-1 flex justify-center">
                            <button
                              type="button"
                              onClick={() => removeSalesItem(index)}
                              className="p-2 text-red-400 hover:text-red-300 hover:bg-red-900 hover:bg-opacity-20 rounded-lg transition-colors duration-200"
                              title="Remove item"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {salesItems.length === 0 && (
                    <div className="text-center py-12 text-slate-400">
                      <ShoppingCart className="mx-auto h-8 w-8 mb-2" />
                      <p>No items added yet. Click "Add Item" to get started.</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Totals */}
              <div className="bg-slate-800 border border-slate-600 rounded-lg p-4">
                <div className="space-y-4">
                  {/* Payment Summary */}
                  <div className="flex items-center justify-between p-3 bg-slate-700 rounded-lg border border-slate-600">
                    <div className="flex items-center space-x-2">
                      <CreditCard className="w-5 h-5 text-yellow-400" />
                      <span className="text-slate-300 font-medium">Payment Method:</span>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      paymentMethod === 'Cash' ? 'bg-green-600 text-white' :
                      paymentMethod === 'UPI' ? 'bg-blue-600 text-white' :
                      paymentMethod === 'Card' ? 'bg-purple-600 text-white' :
                      paymentMethod === 'Bank Transfer' ? 'bg-indigo-600 text-white' :
                      'bg-orange-600 text-white'
                    }`}>
                      {paymentMethod}
                    </span>
                  </div>

                  {/* Totals Row */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        Discount (₹)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={discount}
                        onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        Subtotal
                      </label>
                      <input
                        type="text"
                        value={`₹${calculateSubtotal().toFixed(2)}`}
                        readOnly
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-slate-300"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        <Calculator className="w-4 h-4 inline mr-1" />
                        Grand Total
                      </label>
                      <input
                        type="text"
                        value={`₹${calculateGrandTotal().toFixed(2)}`}
                        readOnly
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-green-400 font-bold text-lg"
                      />
                    </div>

                    <div>
                      <button
                        type="submit"
                        disabled={isSubmitting || salesItems.length === 0}
                        className="w-full flex items-center justify-center px-4 py-3 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 font-medium"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        {isSubmitting ? 'Saving...' : 'Save Sale'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Sales History */}
      <div className="bg-slate-800 rounded-xl border border-slate-600 overflow-hidden shadow-lg">
        <div className="p-6 border-b border-slate-600">
          <h3 className="text-lg font-semibold text-yellow-400">Recent Sales</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-blue-800">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Date</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Reference</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Customer</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Items</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Total</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Payment</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Status</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {salesEntries.slice(0, 20).map((sale) => {
                const actions = [
                  {
                    label: 'Edit',
                    icon: <FileText className="w-4 h-4" />,
                    action: () => {
                      setSelectedCustomer(customers.find(c => c.id === sale.customerId) || null);
                      setCustomerQuery(sale.customerName);
                      setPhoneNumber(sale.phone);
                      setInvoiceRef(sale.ref);
                      setPaymentMethod(sale.payment);
                      setSalesItems(sale.items);
                      setDiscount(sale.discount);
                      setPaymentStatus(sale.status);
                      
                      const newQueries: { [key: number]: string } = {};
                      sale.items.forEach((item, index) => {
                        newQueries[index] = item.name;
                      });
                      setProductQueries(newQueries);
                      
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    },
                    variant: 'default' as const
                  },
                  {
                    label: 'Delete',
                    icon: <Trash2 className="w-4 h-4" />,
                    action: () => {
                      confirm(
                        `Are you sure you want to delete sale "${sale.ref}"?`,
                        () => deleteSalesEntry(sale.id),
                        {
                          title: 'Delete Sale',
                          showDontAskAgain: true,
                          skipKey: 'deleteSale'
                        }
                      );
                    },
                    variant: 'danger' as const
                  },
                  {
                    label: 'Print Preview',
                    icon: <FileText className="w-4 h-4" />,
                    action: () => {
                      const printWindow = window.open('', '_blank');
                      if (printWindow) {
                        const company = {
                          name: 'Segna Pro',
                          phone: '',
                          email: '',
                          gst: '',
                          address: ''
                        };
                        
                        const invoiceHTML = generateInvoiceHTML(sale, company);
                        printWindow.document.write(invoiceHTML);
                        printWindow.document.close();
                      }
                    },
                    variant: 'success' as const
                  },
                  {
                    label: 'Print',
                    icon: <FileText className="w-4 h-4" />,
                    action: () => {
                      const printWindow = window.open('', '_blank');
                      if (printWindow) {
                        const company = {
                          name: 'Segna Pro',
                          phone: '',
                          email: '',
                          gst: '',
                          address: ''
                        };
                        
                        const invoiceHTML = generateInvoiceHTML(sale, company);
                        printWindow.document.write(invoiceHTML);
                        printWindow.document.close();
                        printWindow.print();
                      }
                    },
                    variant: 'default' as const
                  }
                ];

                return (
                  <tr key={sale.id} className="hover:bg-slate-700 transition-colors">
                    <td className="px-6 py-4 text-sm text-white">{formatDateTime(sale.date)}</td>
                    <td className="px-6 py-4 text-sm text-white">
                      <span className="font-mono text-blue-400">{sale.ref}</span>
                    </td>
                    <td className="px-6 py-4 text-sm text-white">
                      <div>{sale.customerName}</div>
                      {sale.phone && <div className="text-xs text-slate-400 mt-1">{sale.phone}</div>}
                    </td>
                    <td className="px-6 py-4 text-sm text-white">{sale.items.length} items</td>
                    <td className="px-6 py-4 text-sm font-medium text-green-400">
                      ₹{sale.grandTotal.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        sale.payment === 'Cash' ? 'bg-green-600 text-white' :
                        sale.payment === 'UPI' ? 'bg-blue-600 text-white' :
                        sale.payment === 'Card' ? 'bg-purple-600 text-white' :
                        sale.payment === 'Bank Transfer' ? 'bg-indigo-600 text-white' :
                        'bg-orange-600 text-white'
                      }`}>
                        {sale.payment}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        sale.status === 'paid' 
                          ? 'bg-green-600 text-white' 
                          : 'bg-red-600 text-white'
                      }`}>
                        {sale.status === 'paid' ? 'Paid' : 'Not Paid'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <ActionDropdown actions={actions} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {salesEntries.length === 0 && (
          <div className="text-center py-12">
            <ShoppingCart className="mx-auto h-12 w-12 text-slate-400" />
            <h3 className="mt-2 text-sm font-medium text-white">No sales yet</h3>
            <p className="mt-1 text-sm text-slate-400">Start by adding your first sale above</p>
          </div>
        )}
      </div>
    </div>
  );
};

// Helper function to generate invoice HTML
const generateInvoiceHTML = (sale: any, company: any) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${day}/${month}/${year} ${hours}:${minutes}`;
  };

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Invoice ${sale.ref}</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 20px; color: #000; background: #fff; }
        .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 20px; margin-bottom: 30px; }
        .company-name { font-size: 28px; font-weight: bold; color: #1e40af; margin-bottom: 10px; }
        .invoice-date { font-size: 18px; font-weight: bold; margin-bottom: 20px; }
        .invoice-details { display: flex; justify-content: space-between; margin-bottom: 30px; }
        .bill-to { flex: 1; }
        .invoice-info { text-align: right; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #000; padding: 10px; text-align: left; }
        th { background: #f0f0f0; font-weight: bold; }
        .totals { text-align: right; margin-top: 20px; }
        .grand-total { font-size: 18px; font-weight: bold; border-top: 2px solid #000; padding-top: 10px; }
        .footer { text-align: center; margin-top: 40px; font-size: 14px; color: #666; }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="invoice-date">Invoice Date: ${formatDate(sale.date)}</div>
        <div class="company-name">${company.name || 'Segna Pro'}</div>
        ${company.address ? `<div>${company.address}</div>` : ''}
        <div>
          ${company.phone ? `Phone: ${company.phone}` : ''} 
          ${company.gst ? `| GST: ${company.gst}` : ''}
        </div>
        <h2 style="margin-top: 20px;">INVOICE</h2>
      </div>
      
      <div class="invoice-details">
        <div class="bill-to">
          <strong>Bill To:</strong><br>
          <strong>${sale.customerName}</strong><br>
          ${sale.phone ? `Phone: ${sale.phone}` : ''}
        </div>
        <div class="invoice-info">
          <strong>Invoice #:</strong> ${sale.ref}<br>
          <strong>Date & Time:</strong> ${formatDateTime(sale.date)}<br>
          <strong>Payment Method:</strong> ${sale.payment}
        </div>
      </div>
      
      <table>
        <thead>
          <tr>
            <th>Item</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          ${sale.items.map((item: any) => `
            <tr>
              <td>${item.name}</td>
              <td>${item.qty}</td>
              <td>₹${item.price.toFixed(2)}</td>
              <td>₹${item.total.toFixed(2)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      
      <div class="totals">
        <div><strong>Subtotal: ₹${sale.subtotal.toFixed(2)}</strong></div>
        ${sale.discount > 0 ? `<div style="color: #dc2626;"><strong>Discount: -₹${sale.discount.toFixed(2)}</strong></div>` : ''}
        <div class="grand-total"><strong>Grand Total: ₹${sale.grandTotal.toFixed(2)}</strong></div>
      </div>
      
      <div class="footer">
        <p>Thank you for your business!</p>
      </div>
    </body>
    </html>
  `;
};

export default SalesEntry;