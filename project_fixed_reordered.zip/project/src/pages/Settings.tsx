import React, { useState, useRef } from 'react';
import { useData } from '../contexts/DataContext';
import { useError } from '../contexts/ErrorContext';
import { useAuth } from '../contexts/AuthContext';
import { usePopup } from '../contexts/PopupContext';
import { formatDate } from '../utils/dateUtils';
import { Save, Upload, Download, Building, Palette, Shield, Calendar, RotateCcw } from 'lucide-react';

const Settings: React.FC = () => {
  const { company, updateCompany, exportToExcel, importFromExcel, exportBackup, importBackup } = useData();
  const { showError } = useError();
  const { setAuthEnabled, isAuthEnabled } = useAuth();
  const { resetSkips } = usePopup();
  
  const [companyData, setCompanyData] = useState(company);
  const [logo, setLogo] = useState('');
  const [theme, setTheme] = useState({
    bgColor: '#0f172a',
    textColor: '#ffffff'
  });
  const [backupSchedule, setBackupSchedule] = useState('monthly');
  const [pin, setPin] = useState('');
  const logoInputRef = useRef<HTMLInputElement>(null);

  const lastSavedDate = localStorage.getItem('lastSavedDate') || 'Never';

  const handleSaveCompany = () => {
    try {
      updateCompany(companyData);
      localStorage.setItem('lastSavedDate', new Date().toISOString());
      showError('Company information saved successfully!', 'info');
    } catch (error) {
      showError('Failed to save company information');
    }
  };

  const handleLogoUpload = async (file: File) => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      return new Promise<string>((resolve, reject) => {
        img.onload = () => {
          const maxDim = 128;
          const scale = Math.min(maxDim / img.width, maxDim / img.height, 1);
          const w = Math.max(1, Math.round(img.width * scale));
          const h = Math.max(1, Math.round(img.height * scale));
          
          canvas.width = w;
          canvas.height = h;
          ctx?.drawImage(img, 0, 0, w, h);
          
          try {
            const dataUrl = canvas.toDataURL('image/webp', 0.8);
            setLogo(dataUrl);
            localStorage.setItem('companyLogo', dataUrl);
            resolve(dataUrl);
          } catch (e) {
            const reader = new FileReader();
            reader.onload = () => {
              const result = reader.result as string;
              setLogo(result);
              localStorage.setItem('companyLogo', result);
              resolve(result);
            };
            reader.onerror = () => reject(new Error('File read error'));
            reader.readAsDataURL(file);
          }
        };
        img.onerror = () => reject(new Error('Invalid image'));
        
        const reader = new FileReader();
        reader.onload = () => img.src = reader.result as string;
        reader.onerror = () => reject(new Error('File read error'));
        reader.readAsDataURL(file);
      });
    } catch (error) {
      showError('Failed to process logo');
    }
  };

  const applyTheme = () => {
    document.documentElement.style.setProperty('--bg-color', theme.bgColor);
    document.documentElement.style.setProperty('--text-color', theme.textColor);
    localStorage.setItem('appTheme', JSON.stringify(theme));
    showError('Theme applied successfully!', 'info');
  };

  const makeDefault = () => {
    try {
      localStorage.setItem('defaultCompany', JSON.stringify(companyData));
      localStorage.setItem('defaultTheme', JSON.stringify(theme));
      if (logo) {
        localStorage.setItem('defaultLogo', logo);
      }
      showError('Settings saved as default!', 'info');
    } catch (error) {
      showError('Failed to save defaults');
    }
  };

  const handlePinChange = (newPin: string) => {
    setPin(newPin);
    localStorage.setItem('appPin', newPin);
    showError('PIN updated successfully!', 'info');
  };

  const resetPopupSettings = () => {
    resetSkips();
    showError('Popup settings reset successfully!', 'info');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Company Information */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl border border-slate-600 shadow-lg">
        <div className="p-6 border-b border-slate-600">
          <h3 className="text-lg font-semibold text-yellow-400 flex items-center">
            <Building className="w-5 h-5 mr-2" />
            Company Information
          </h3>
          <p className="text-sm text-slate-400">Configure your business details</p>
        </div>
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Company Name
              </label>
              <input
                type="text"
                value={companyData.name}
                onChange={(e) => setCompanyData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Phone Number
              </label>
              <input
                type="text"
                value={companyData.phone}
                onChange={(e) => setCompanyData(prev => ({ ...prev, phone: e.target.value }))}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Email
              </label>
              <input
                type="email"
                value={companyData.email}
                onChange={(e) => setCompanyData(prev => ({ ...prev, email: e.target.value }))}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                GST Number
              </label>
              <input
                type="text"
                value={companyData.gst}
                onChange={(e) => setCompanyData(prev => ({ ...prev, gst: e.target.value }))}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Company Address
            </label>
            <textarea
              value={companyData.address}
              onChange={(e) => setCompanyData(prev => ({ ...prev, address: e.target.value }))}
              rows={3}
              className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Company Logo
            </label>
            <div className="flex items-center space-x-4">
              {logo && (
                <img src={logo} alt="Company Logo" className="w-16 h-16 rounded-lg object-cover" />
              )}
              <label className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 cursor-pointer">
                <Upload className="w-4 h-4 mr-2" />
                Upload Logo
                <input
                  ref={logoInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => e.target.files?.[0] && handleLogoUpload(e.target.files[0])}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          <button
            onClick={handleSaveCompany}
            className="flex items-center px-4 py-2 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Company Info
          </button>
        </div>
      </div>

      {/* Data Management */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl border border-slate-600 shadow-lg">
        <div className="p-6 border-b border-slate-600">
          <h3 className="text-lg font-semibold text-yellow-400">📊 Data Management</h3>
          <p className="text-sm text-slate-400">Import and export your business data</p>
        </div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => exportToExcel('all')}
              className="flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
            >
              <Download className="w-4 h-4 mr-2" />
              Export All (Excel)
            </button>
            
            <label className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 cursor-pointer">
              <Upload className="w-4 h-4 mr-2" />
              Import Sales
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={(e) => e.target.files?.[0] && importFromExcel(e.target.files[0], 'sales')}
                className="hidden"
              />
            </label>
            
            <label className="flex items-center justify-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors duration-200 cursor-pointer">
              <Upload className="w-4 h-4 mr-2" />
              Import All Data
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={(e) => e.target.files?.[0] && importFromExcel(e.target.files[0], 'all')}
                className="hidden"
              />
            </label>
          </div>

          <div className="text-center text-sm text-slate-400">
            Last saved: {lastSavedDate !== 'Never' ? formatDate(lastSavedDate) : 'Never'}
          </div>
        </div>
      </div>

      {/* Backup & Restore */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl border border-slate-600 shadow-lg">
        <div className="p-6 border-b border-slate-600">
          <h3 className="text-lg font-semibold text-yellow-400">💾 Backup & Restore</h3>
          <p className="text-sm text-slate-400">Protect your business data with regular backups</p>
        </div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button
              onClick={exportBackup}
              className="flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
            >
              <Download className="w-4 h-4 mr-2" />
              Export Backup
            </button>
            
            <label className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 cursor-pointer">
              <Upload className="w-4 h-4 mr-2" />
              Restore Backup
              <input
                type="file"
                accept=".json"
                onChange={(e) => e.target.files?.[0] && importBackup(e.target.files[0])}
                className="hidden"
              />
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              <Calendar className="w-4 h-4 inline mr-1" />
              Backup Schedule
            </label>
            <select
              value={backupSchedule}
              onChange={(e) => setBackupSchedule(e.target.value)}
              className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
            >
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
              <option value="manual">Manual Only</option>
            </select>
          </div>
        </div>
      </div>

      {/* Theme Customization */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl border border-slate-600 shadow-lg">
        <div className="p-6 border-b border-slate-600">
          <h3 className="text-lg font-semibold text-yellow-400 flex items-center">
            <Palette className="w-5 h-5 mr-2" />
            Theme Customization
          </h3>
          <p className="text-sm text-slate-400">Customize the appearance of your dashboard</p>
        </div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Background Color
              </label>
              <input
                type="color"
                value={theme.bgColor}
                onChange={(e) => setTheme(prev => ({ ...prev, bgColor: e.target.value }))}
                className="w-full h-10 bg-slate-700 border border-slate-600 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Text Color
              </label>
              <input
                type="color"
                value={theme.textColor}
                onChange={(e) => setTheme(prev => ({ ...prev, textColor: e.target.value }))}
                className="w-full h-10 bg-slate-700 border border-slate-600 rounded-lg"
              />
            </div>
          </div>

          <div className="flex space-x-3">
            <button
              onClick={applyTheme}
              className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors duration-200"
            >
              <Palette className="w-4 h-4 mr-2" />
              Apply Theme
            </button>
            
            <button
              onClick={makeDefault}
              className="flex items-center px-4 py-2 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium"
            >
              Make Default
            </button>
          </div>
        </div>
      </div>

      {/* Security Settings */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl border border-slate-600 shadow-lg">
        <div className="p-6 border-b border-slate-600">
          <h3 className="text-lg font-semibold text-yellow-400 flex items-center">
            <Shield className="w-5 h-5 mr-2" />
            Security Settings
          </h3>
          <p className="text-sm text-slate-400">Configure authentication and security options</p>
        </div>
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between p-3 border border-slate-600 rounded-lg">
            <div>
              <h4 className="font-medium text-white">PIN Authentication</h4>
              <p className="text-sm text-slate-400">Require PIN to access the dashboard</p>
            </div>
            <button
              onClick={() => setAuthEnabled(!isAuthEnabled)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-offset-2 ${
                isAuthEnabled ? 'bg-yellow-500' : 'bg-slate-600'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  isAuthEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {isAuthEnabled && (
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Change PIN
              </label>
              <input
                type="password"
                value={pin}
                onChange={(e) => handlePinChange(e.target.value)}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                placeholder="Enter new PIN"
                maxLength={4}
              />
            </div>
          )}

          <button
            onClick={resetPopupSettings}
            className="flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors duration-200"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset Popup Settings
          </button>
        </div>
      </div>

      {/* Footer Settings */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl border border-slate-600 shadow-lg">
        <div className="p-6 border-b border-slate-600">
          <h3 className="text-lg font-semibold text-yellow-400">Footer Settings</h3>
          <p className="text-sm text-slate-400">Configure footer display options</p>
        </div>
        <div className="p-6">
          <div className="text-center p-4 bg-slate-700 rounded-lg border border-slate-600">
            <p className="text-slate-300 text-sm">
              © {new Date().getFullYear()} {companyData.name || 'Segna Pro'}. All rights reserved.
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Footer visibility can be toggled using the button in the bottom-right corner
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;