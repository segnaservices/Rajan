import React, { useState } from 'react';
import { useNotifications } from '../contexts/NotificationContext';
import { formatDateTime, formatDate } from '../utils/dateUtils';
import { Bell, Search, RefreshCw, CheckCheck, Trash2, ExternalLink, ChevronDown, ChevronRight, Settings } from 'lucide-react';

const Notifications: React.FC = () => {
  const {
    notifications,
    settings,
    isLoading,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    updateSettings,
    refreshNotifications,
    getNotificationsBySource,
    getNotificationsByCategory,
  } = useNotifications();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterBy, setFilterBy] = useState<'all' | 'unread' | 'read'>('all');
  const [sortBy, setSortBy] = useState<'date' | 'priority' | 'source'>('date');
  const [groupBy, setGroupBy] = useState<'source' | 'category'>('source');
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [showSettings, setShowSettings] = useState(false);

  const filteredNotifications = notifications
    .filter(notification => {
      const matchesSearch = notification.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           notification.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           notification.source.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesFilter = filterBy === 'all' || 
                           (filterBy === 'read' && notification.isRead) ||
                           (filterBy === 'unread' && !notification.isRead);
      
      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'date':
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        case 'priority':
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          return priorityOrder[b.priority] - priorityOrder[a.priority];
        case 'source':
          return a.source.localeCompare(b.source);
        default:
          return 0;
      }
    });

  const groupedNotifications = groupBy === 'source' 
    ? getNotificationsBySource() 
    : getNotificationsByCategory();

  const toggleGroup = (groupName: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(groupName)) {
      newExpanded.delete(groupName);
    } else {
      newExpanded.add(groupName);
    }
    setExpandedGroups(newExpanded);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-500';
      case 'medium': return 'text-yellow-500';
      case 'low': return 'text-green-500';
      default: return 'text-gray-500';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Government Jobs': return '🏛️';
      case 'Bank Exams': return '🏦';
      case 'Tax': return '📊';
      case 'Banking': return '💳';
      case 'System': return '⚙️';
      default: return '📢';
    }
  };

  const getSourceColor = (source: string) => {
    switch (source) {
      case 'UPSC': return 'bg-red-600';
      case 'SSC': return 'bg-blue-600';
      case 'Railway': return 'bg-green-600';
      case 'Banking': return 'bg-purple-600';
      case 'RBI': return 'bg-indigo-600';
      case 'State PSC': return 'bg-orange-600';
      default: return 'bg-gray-600';
    }
  };
  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white flex items-center">
            <Bell className="w-8 h-8 mr-3" />
            Notifications
            {unreadCount > 0 && (
              <span className="ml-2 px-2 py-1 bg-red-500 text-white text-sm rounded-full">
                {unreadCount}
              </span>
            )}
          </h2>
          <p className="text-slate-300">Stay updated with important business notifications</p>
        </div>
        
        <div className="flex space-x-3">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-200"
          >
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </button>
          
          <button
            onClick={refreshNotifications}
            disabled={isLoading}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          
          <button
            onClick={markAllAsRead}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
          >
            <CheckCheck className="w-4 h-4 mr-2" />
            Mark All Read
          </button>
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="bg-slate-800 rounded-xl border border-slate-600 p-6">
          <h3 className="text-lg font-semibold text-yellow-400 mb-4">Notification Settings</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="flex items-center space-x-2 mb-4">
                <input
                  type="checkbox"
                  checked={settings.enabled}
                  onChange={(e) => updateSettings({ enabled: e.target.checked })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-white">Enable Notifications</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={settings.goldSilverAlerts}
                  onChange={(e) => updateSettings({ goldSilverAlerts: e.target.checked })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-white">Gold/Silver Price Alerts</span>
              </label>
              
              <label className="flex items-center space-x-2 mt-4">
                <input
                  type="checkbox"
                  checked={settings.examNotifications}
                  onChange={(e) => updateSettings({ examNotifications: e.target.checked })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-white">Exam Notifications</span>
              </label>
              
              <label className="flex items-center space-x-2 mt-4">
                <input
                  type="checkbox"
                  checked={settings.governmentJobAlerts}
                  onChange={(e) => updateSettings({ governmentJobAlerts: e.target.checked })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-white">Government Job Alerts</span>
              </label>
              
              <label className="flex items-center space-x-2 mt-4">
                <input
                  type="checkbox"
                  checked={settings.bankExamAlerts}
                  onChange={(e) => updateSettings({ bankExamAlerts: e.target.checked })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-white">Bank Exam Alerts</span>
              </label>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Auto-refresh interval (minutes)
              </label>
              <input
                type="number"
                min="5"
                max="120"
                value={settings.autoRefresh}
                onChange={(e) => updateSettings({ autoRefresh: parseInt(e.target.value) })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
              />
            </div>
          </div>
        </div>
      )}

      {/* Filters and Search */}
      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-br from-red-600 to-red-700 rounded-xl p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-100 text-sm">Government Jobs</p>
              <p className="text-xl font-bold">
                {notifications.filter(n => n.category === 'Government Jobs').length}
              </p>
            </div>
            <span className="text-2xl">🏛️</span>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-xl p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm">Bank Exams</p>
              <p className="text-xl font-bold">
                {notifications.filter(n => n.category === 'Bank Exams').length}
              </p>
            </div>
            <span className="text-2xl">🏦</span>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-orange-600 to-orange-700 rounded-xl p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 text-sm">High Priority</p>
              <p className="text-xl font-bold">
                {notifications.filter(n => n.priority === 'high' && !n.isRead).length}
              </p>
            </div>
            <span className="text-2xl">🚨</span>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">This Week</p>
              <p className="text-xl font-bold">
                {notifications.filter(n => {
                  const notificationDate = new Date(n.date);
                  const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                  return notificationDate > weekAgo;
                }).length}
              </p>
            </div>
            <span className="text-2xl">📅</span>
          </div>
        </div>
      </div>

      <div className="bg-slate-800 rounded-xl border border-slate-600 p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search notifications..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
            />
          </div>
          
          <select
            value={filterBy}
            onChange={(e) => setFilterBy(e.target.value as any)}
            className="px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
          >
            <option value="all">All Notifications</option>
            <option value="unread">Unread Only</option>
            <option value="read">Read Only</option>
          </select>
          
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
          >
            <option value="date">Sort by Date</option>
            <option value="priority">Sort by Priority</option>
            <option value="source">Sort by Source</option>
          </select>
          
          <select
            value={groupBy}
            onChange={(e) => setGroupBy(e.target.value as any)}
            className="px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
          >
            <option value="source">Group by Source</option>
            <option value="category">Group by Category</option>
          </select>
        </div>
      </div>

      {/* Notifications List */}
      <div className="space-y-4">
        {Object.entries(groupedNotifications).map(([groupName, groupNotifications]) => {
          const filteredGroupNotifications = groupNotifications.filter(notification => {
            const matchesSearch = notification.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                 notification.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                 notification.source.toLowerCase().includes(searchQuery.toLowerCase());
            
            const matchesFilter = filterBy === 'all' || 
                                 (filterBy === 'read' && notification.isRead) ||
                                 (filterBy === 'unread' && !notification.isRead);
            
            return matchesSearch && matchesFilter;
          });

          if (filteredGroupNotifications.length === 0) return null;

          const isExpanded = expandedGroups.has(groupName);
          const unreadInGroup = filteredGroupNotifications.filter(n => !n.isRead).length;

          return (
            <div key={groupName} className="bg-slate-800 rounded-xl border border-slate-600 overflow-hidden">
              <button
                onClick={() => toggleGroup(groupName)}
                className="w-full flex items-center justify-between p-4 hover:bg-slate-700 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  {isExpanded ? <ChevronDown className="w-5 h-5 text-slate-400" /> : <ChevronRight className="w-5 h-5 text-slate-400" />}
                  <h3 className="text-lg font-semibold text-yellow-400">{groupName}</h3>
                  <span className="text-sm text-slate-400">({filteredGroupNotifications.length})</span>
                  {unreadInGroup > 0 && (
                    <span className="px-2 py-1 bg-red-500 text-white text-xs rounded-full">
                      {unreadInGroup} new
                    </span>
                  )}
                </div>
              </button>
              
              {isExpanded && (
                <div className="border-t border-slate-700">
                  {filteredGroupNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 border-b border-slate-700 last:border-b-0 ${
                        !notification.isRead ? 'bg-slate-700' : ''
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="text-lg">{getCategoryIcon(notification.category)}</span>
                            <h4 className={`font-medium ${!notification.isRead ? 'text-white' : 'text-slate-300'}`}>
                              {notification.title}
                            </h4>
                            <span className={`text-xs px-2 py-1 rounded-full text-white ${
                              notification.priority === 'high' ? 'bg-red-600' :
                              notification.priority === 'medium' ? 'bg-yellow-600' :
                              'bg-green-600'
                            }`}>
                              {notification.priority}
                            </span>
                            <span className={`text-xs px-2 py-1 rounded-full text-white ${getSourceColor(notification.source)}`}>
                              {notification.source}
                            </span>
                            {!notification.isRead && (
                              <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                            )}
                          </div>
                          
                          <p className="text-sm text-slate-400 mb-2">{notification.content}</p>
                          
                          <div className="flex items-center space-x-4 text-xs text-slate-500">
                            <span>{formatDate(notification.date)}</span>
                            <span>{notification.category}</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2 ml-4">
                          {notification.url && (
                            <button
                              onClick={() => window.open(notification.url, '_blank')}
                              className="p-2 text-blue-400 hover:text-blue-300 transition-colors"
                              title="Open Link"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </button>
                          )}
                          
                          {!notification.isRead && (
                            <button
                              onClick={() => markAsRead(notification.id)}
                              className="p-2 text-green-400 hover:text-green-300 transition-colors"
                              title="Mark as Read"
                            >
                              <CheckCheck className="w-4 h-4" />
                            </button>
                          )}
                          
                          <button
                            onClick={() => deleteNotification(notification.id)}
                            className="p-2 text-red-400 hover:text-red-300 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredNotifications.length === 0 && (
        <div className="text-center py-12">
          <Bell className="mx-auto h-12 w-12 text-slate-400" />
          <h3 className="mt-2 text-sm font-medium text-white">No notifications found</h3>
          <p className="mt-1 text-sm text-slate-400">
            {searchQuery ? 'Try adjusting your search criteria' : 'All caught up! No new notifications.'}
          </p>
        </div>
      )}

      {/* Loading State */}
      {isLoading && (
        <div className="text-center py-8">
          <RefreshCw className="mx-auto h-8 w-8 text-blue-500 animate-spin" />
          <p className="mt-2 text-sm text-slate-400">Refreshing notifications...</p>
        </div>
      )}
    </div>
  );
};

export default Notifications;