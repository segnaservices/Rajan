import React, { useEffect, useState } from "react";
import Chart from "chart.js/auto";

interface RateEntry {
  date: string;
  price: number;
}

interface RatesResponse {
  gold: RateEntry[];
  silver: RateEntry[];
  summaries: {
    gold: string;
    silver: string;
  };
}

const GoldSilver: React.FC = () => {
  const [data, setData] = useState<RatesResponse | null>(null);
  const [activeTab, setActiveTab] = useState<"gold" | "silver">("gold");
  const [lastUpdated, setLastUpdated] = useState<string>("—");
  const [goldChart, setGoldChart] = useState<Chart | null>(null);
  const [silverChart, setSilverChart] = useState<Chart | null>(null);

  const API_BASE = "http://localhost:3000"; // change after deploy

  function fmtINR(v: number) {
    return "₹" + v.toLocaleString("en-IN", { minimumFractionDigits: v % 1 ? 2 : 0 });
  }

  function humanDate(d: string) {
    return `${d.slice(6, 8)} ${
      ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][+d.slice(4, 6) - 1]
    } ${d.slice(0, 4)}`;
  }

  function renderHistory(
    entries: RateEntry[],
    tableId: string,
    chartId: string,
    label: string,
    existingChart: Chart | null,
    setChart: React.Dispatch<React.SetStateAction<Chart | null>>
  ) {
    const tbody = document.querySelector<HTMLTableSectionElement>(tableId)!;
    tbody.innerHTML = "";

    const labels: string[] = [];
    const points: number[] = [];

    entries.forEach((row, i) => {
      const prev = i > 0 ? entries[i - 1].price : null;
      let flow = "-";
      if (prev !== null) {
        const diff = row.price - prev;
        if (diff > 0) flow = `<span style="color:green;font-weight:600">▲ ${fmtINR(diff)}</span>`;
        else if (diff < 0) flow = `<span style="color:red;font-weight:600">▼ ${fmtINR(Math.abs(diff))}</span>`;
        else flow = `<span style="color:gray">➝ No change</span>`;
      }
      tbody.insertAdjacentHTML(
        "beforeend",
        `<tr><td>${humanDate(row.date)}</td><td>${fmtINR(row.price)}</td><td>${flow}</td></tr>`
      );
      labels.push(humanDate(row.date));
      points.push(row.price);
    });

    if (existingChart) existingChart.destroy();
    const ctx = document.querySelector<HTMLCanvasElement>(chartId)!.getContext("2d")!;
    const chart = new Chart(ctx, {
      type: "line",
      data: {
        labels,
        datasets: [
          {
            label: `${label} (₹/g)`,
            data: points,
            borderColor: label.includes("Gold") ? "#b8860b" : "#616161",
            tension: 0.3,
            pointRadius: 4,
          },
        ],
      },
      options: { responsive: true },
    });
    setChart(chart);
  }

  async function loadRates() {
    try {
      const res = await fetch(`${API_BASE}/rates`);
      const json: RatesResponse = await res.json();
      setData(json);
      setLastUpdated(new Date().toLocaleString());

      renderHistory(json.gold, "#goldTable tbody", "#goldChart", "22K Gold", goldChart, setGoldChart);
      renderHistory(json.silver, "#silverTable tbody", "#silverChart", "Silver", silverChart, setSilverChart);
    } catch (e) {
      console.error("❌ Fetch error:", e);
    }
  }

  useEffect(() => {
    loadRates();
    const interval = setInterval(loadRates, 10800000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-2">Chennai — 22K Gold & Silver</h1>
      <p className="text-gray-500 text-sm mb-4">Prices in ₹ per gram. Last 7 days (via ChatGPT API).</p>

      <div className="flex gap-2 mb-4">
        <button
          className={`flex-1 p-2 border rounded ${activeTab === "gold" ? "bg-yellow-400" : "bg-white"}`}
          onClick={() => setActiveTab("gold")}
        >
          22K Gold
        </button>
        <button
          className={`flex-1 p-2 border rounded ${activeTab === "silver" ? "bg-yellow-400" : "bg-white"}`}
          onClick={() => setActiveTab("silver")}
        >
          Silver
        </button>
      </div>

      {activeTab === "gold" && data && (
        <div>
          <div className="bg-white p-4 rounded shadow mb-4">
            <div className="text-sm text-gray-500">22K Gold</div>
            <div className="text-lg font-bold">{fmtINR(data.gold[data.gold.length - 1].price)}</div>
            <div className="text-sm mt-1">{data.summaries.gold}</div>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold mb-2">7-Day History</h3>
            <table className="w-full text-sm border-collapse" id="goldTable">
              <thead>
                <tr className="bg-gray-50 text-gray-500">
                  <th className="text-left p-2">Date</th>
                  <th className="text-right p-2">₹ / gram</th>
                  <th className="text-right p-2">Flow</th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
            <canvas id="goldChart" height="160" />
          </div>
        </div>
      )}

      {activeTab === "silver" && data && (
        <div>
          <div className="bg-white p-4 rounded shadow mb-4">
            <div className="text-sm text-gray-500">Silver</div>
            <div className="text-lg font-bold">{fmtINR(data.silver[data.silver.length - 1].price)}</div>
            <div className="text-sm mt-1">{data.summaries.silver}</div>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold mb-2">7-Day History</h3>
            <table className="w-full text-sm border-collapse" id="silverTable">
              <thead>
                <tr className="bg-gray-50 text-gray-500">
                  <th className="text-left p-2">Date</th>
                  <th className="text-right p-2">₹ / gram</th>
                  <th className="text-right p-2">Flow</th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
            <canvas id="silverChart" height="160" />
          </div>
        </div>
      )}

      <div className="text-xs text-gray-500 mt-4 text-right">Last updated: {lastUpdated}</div>
    </div>
  );
};

export default GoldSilver;
