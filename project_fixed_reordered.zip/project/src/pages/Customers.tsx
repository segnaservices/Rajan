import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { useError } from '../contexts/ErrorContext';
import { usePopup } from '../contexts/PopupContext';
import ActionDropdown from '../components/ActionDropdown';
import { formatDate } from '../utils/dateUtils';
import { Plus, Search, Mail, Phone, Building, Edit, Trash2, Users } from 'lucide-react';

const Customers: React.FC = () => {
  const { customers, addCustomer, updateCustomer, deleteCustomer } = useData();
  const { showError } = useError();
  const { confirm } = usePopup();
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    address: '',
  });

  const filteredCustomers = customers
    .filter(customer =>
      customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.phone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.company.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()); // Latest first

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.phone.trim()) {
      showError('Name and phone number are required');
      return;
    }

    try {
      if (editingId) {
        updateCustomer(editingId, formData);
      } else {
        addCustomer(formData);
      }
      
      setFormData({ name: '', email: '', phone: '', company: '', address: '' });
      setEditingId(null);
      setIsModalOpen(false);
    } catch (error) {
      showError('Failed to save customer');
    }
  };

  const handleEdit = (customer: any) => {
    setFormData({
      name: customer.name,
      email: customer.email,
      phone: customer.phone,
      company: customer.company,
      address: customer.address,
    });
    setEditingId(customer.id);
    setIsModalOpen(true);
  };

  const handleDelete = (id: string, name: string) => {
    confirm(
      `Are you sure you want to delete "${name}"?`,
      () => deleteCustomer(id),
      {
        title: 'Delete Customer',
        showDontAskAgain: true,
        skipKey: 'deleteCustomer'
      }
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white">👥 Customer Management</h2>
          <p className="text-slate-300">Manage your customer database</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center px-4 py-2 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Customer
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
        <input
          type="text"
          placeholder="Search customers..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
        />
      </div>

      {/* Customers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCustomers.map((customer) => {
          const actions = [
            {
              label: 'Edit',
              icon: <Edit className="w-4 h-4" />,
              action: () => handleEdit(customer),
              variant: 'default' as const
            },
            {
              label: 'Delete',
              icon: <Trash2 className="w-4 h-4" />,
              action: () => handleDelete(customer.id, customer.name),
              variant: 'danger' as const
            }
          ];

          return (
            <div key={customer.id} className="group bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 border border-slate-600 hover:border-yellow-400 transition-all duration-200 hover:transform hover:-translate-y-1 shadow-lg">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-white">{customer.name}</h3>
                    <p className="text-sm text-slate-400">{customer.ref} • {customer.company}</p>
                  </div>
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    <ActionDropdown actions={actions} />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-slate-300">
                    <Mail className="w-4 h-4 mr-2 text-slate-400" />
                    {customer.email || 'No email'}
                  </div>
                  <div className="flex items-center text-sm text-slate-300">
                    <Phone className="w-4 h-4 mr-2 text-slate-400" />
                    {customer.phone}
                  </div>
                  <div className="flex items-center text-sm text-slate-300">
                    <Building className="w-4 h-4 mr-2 text-slate-400" />
                    {customer.company || 'No company'}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-700">
                  <p className="text-xs text-slate-500">
                    Added {formatDate(customer.createdAt)}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredCustomers.length === 0 && (
        <div className="text-center py-12">
          <Users className="mx-auto h-12 w-12 text-slate-400" />
          <h3 className="mt-2 text-sm font-medium text-white">No customers found</h3>
          <p className="mt-1 text-sm text-slate-400">
            {searchQuery ? 'Try adjusting your search criteria' : 'Get started by adding your first customer'}
          </p>
        </div>
      )}

      {/* Add/Edit Customer Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-lg shadow-xl max-w-md w-full border border-slate-600">
            <div className="p-6 border-b border-slate-600">
              <h3 className="text-lg font-semibold text-white">
                {editingId ? 'Edit Customer' : 'Add New Customer'}
              </h3>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Phone *
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Company
                </label>
                <input
                  type="text"
                  value={formData.company}
                  onChange={(e) => setFormData(prev => ({ ...prev, company: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Address
                </label>
                <textarea
                  value={formData.address}
                  onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingId(null);
                    setFormData({ name: '', email: '', phone: '', company: '', address: '' });
                  }}
                  className="px-4 py-2 border border-slate-600 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors duration-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium"
                >
                  {editingId ? 'Update' : 'Add'} Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Customers;