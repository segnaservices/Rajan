import React, { useEffect, useRef } from 'react';
import { useData } from '../contexts/DataContext';
import { FileText, Download, TrendingUp, TrendingDown, DollarSign, Calendar } from 'lucide-react';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

const Reports: React.FC = () => {
  const { salesEntries, expenses, exportToExcel } = useData();
  const monthlyChartRef = useRef<HTMLCanvasElement>(null);
  const revenueChartRef = useRef<HTMLCanvasElement>(null);
  const monthlyChart = useRef<Chart | null>(null);
  const revenueChart = useRef<Chart | null>(null);

  const totalSales = salesEntries.reduce((sum, sale) => sum + sale.grandTotal, 0);
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const netProfit = totalSales - totalExpenses;

  // Calculate monthly data
  const monthlyData: { [key: string]: { sales: number; expenses: number } } = {};
  
  salesEntries.forEach(sale => {
    const month = sale.date.slice(0, 7);
    if (!monthlyData[month]) monthlyData[month] = { sales: 0, expenses: 0 };
    monthlyData[month].sales += sale.grandTotal;
  });

  expenses.forEach(expense => {
    const month = expense.date.slice(0, 7);
    if (!monthlyData[month]) monthlyData[month] = { sales: 0, expenses: 0 };
    monthlyData[month].expenses += expense.amount;
  });

  const months = Object.keys(monthlyData).sort();
  const monthlyProfit = months.map(month => monthlyData[month].sales - monthlyData[month].expenses);

  // All transactions for ledger
  const allTransactions = [
    ...salesEntries.map(sale => ({
      ...sale,
      type: 'Sale' as const,
      amount: sale.grandTotal,
      description: `Sale to ${sale.customerName}`
    })),
    ...expenses.map(expense => ({
      ...expense,
      type: 'Expense' as const,
      amount: expense.amount,
      description: expense.description
    }))
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  useEffect(() => {
    // Monthly Profit Chart
    if (monthlyChartRef.current) {
      if (monthlyChart.current) {
        monthlyChart.current.destroy();
      }

      monthlyChart.current = new Chart(monthlyChartRef.current, {
        type: 'line',
        data: {
          labels: months,
          datasets: [{
            label: 'Monthly Profit ($)',
            data: monthlyProfit,
            borderColor: '#22c55e',
            backgroundColor: 'rgba(34, 197, 94, 0.1)',
            fill: true,
            tension: 0.4
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: { 
              labels: { color: '#fff' }
            }
          },
          scales: {
            x: { 
              ticks: { color: '#fff' },
              grid: { color: 'rgba(255, 255, 255, 0.1)' }
            },
            y: { 
              ticks: { color: '#fff' },
              grid: { color: 'rgba(255, 255, 255, 0.1)' }
            }
          }
        }
      });
    }

    // Revenue Breakdown Chart
    if (revenueChartRef.current) {
      if (revenueChart.current) {
        revenueChart.current.destroy();
      }

      revenueChart.current = new Chart(revenueChartRef.current, {
        type: 'doughnut',
        data: {
          labels: ['Sales Revenue', 'Total Expenses'],
          datasets: [{
            data: [totalSales, totalExpenses],
            backgroundColor: ['#22c55e', '#ef4444'],
            borderWidth: 2,
            borderColor: '#1e293b'
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: { 
              labels: { color: '#fff' }
            }
          }
        }
      });
    }

    return () => {
      if (monthlyChart.current) monthlyChart.current.destroy();
      if (revenueChart.current) revenueChart.current.destroy();
    };
  }, [months, monthlyProfit, totalSales, totalExpenses]);

  const exportPDF = async () => {
    try {
      const html2pdf = await import('html2pdf.js');
      const element = document.getElementById('reports-content');
      
      const opt = {
        margin: 0.5,
        filename: `Business_Report_${new Date().toISOString().slice(0, 10)}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, backgroundColor: '#1e293b' },
        jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
      };
      
      html2pdf.default().set(opt).from(element).save();
    } catch (error) {
      console.error('PDF export failed:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white">Financial Reports</h2>
          <p className="text-slate-300">Comprehensive business analytics and reports</p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={() => exportToExcel('all')}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
          >
            <Download className="w-4 h-4 mr-2" />
            Export Excel
          </button>
          <button
            onClick={exportPDF}
            className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200"
          >
            <FileText className="w-4 h-4 mr-2" />
            Export PDF
          </button>
        </div>
      </div>

      <div id="reports-content">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100">Total Sales</p>
                <p className="text-2xl font-bold">${totalSales.toLocaleString()}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-200" />
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-red-600 to-red-700 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100">Total Expenses</p>
                <p className="text-2xl font-bold">${totalExpenses.toLocaleString()}</p>
              </div>
              <TrendingDown className="w-8 h-8 text-red-200" />
            </div>
          </div>
          
          <div className={`bg-gradient-to-br ${netProfit >= 0 ? 'from-blue-600 to-blue-700' : 'from-orange-600 to-orange-700'} rounded-xl p-6 text-white`}>
            <div className="flex items-center justify-between">
              <div>
                <p className={netProfit >= 0 ? 'text-blue-100' : 'text-orange-100'}>Net {netProfit >= 0 ? 'Profit' : 'Loss'}</p>
                <p className="text-2xl font-bold">${Math.abs(netProfit).toLocaleString()}</p>
              </div>
              <DollarSign className={`w-8 h-8 ${netProfit >= 0 ? 'text-blue-200' : 'text-orange-200'}`} />
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-slate-800 rounded-xl p-6 border border-slate-600">
            <h3 className="text-lg font-semibold text-yellow-400 mb-4">Monthly Profit Trend</h3>
            <canvas ref={monthlyChartRef}></canvas>
          </div>
          
          <div className="bg-slate-800 rounded-xl p-6 border border-slate-600">
            <h3 className="text-lg font-semibold text-yellow-400 mb-4">Revenue Breakdown</h3>
            <canvas ref={revenueChartRef}></canvas>
          </div>
        </div>

        {/* Transaction Ledger */}
        <div className="bg-slate-800 rounded-xl border border-slate-600 overflow-hidden">
          <div className="p-6 border-b border-slate-600">
            <h3 className="text-lg font-semibold text-yellow-400">Transaction Ledger</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-blue-800">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Date</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Reference</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Type</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-yellow-400">Description</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-yellow-400">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {allTransactions.slice(0, 20).map((transaction) => (
                  <tr key={transaction.id} className="hover:bg-slate-700 transition-colors">
                    <td className="px-6 py-4 text-sm text-white">{transaction.date}</td>
                    <td className="px-6 py-4 text-sm text-white">{transaction.ref}</td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        transaction.type === 'Sale' 
                          ? 'bg-green-600 text-white' 
                          : 'bg-red-600 text-white'
                      }`}>
                        {transaction.type}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-white">{transaction.description}</td>
                    <td className={`px-6 py-4 text-sm font-medium text-right ${
                      transaction.type === 'Sale' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {transaction.type === 'Sale' ? '+' : '-'}${transaction.amount.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {allTransactions.length === 0 && (
            <div className="text-center py-12">
              <FileText className="mx-auto h-12 w-12 text-slate-400" />
              <h3 className="mt-2 text-sm font-medium text-white">No transactions yet</h3>
              <p className="mt-1 text-sm text-slate-400">Start by adding sales or expenses</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Reports;