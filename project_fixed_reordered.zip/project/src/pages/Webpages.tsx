import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { useError } from '../contexts/ErrorContext';
import { usePopup } from '../contexts/PopupContext';
import ActionDropdown from '../components/ActionDropdown';
import { Plus, Search, Globe, Edit, Trash2, Download, Upload, Maximize, Minimize, ExternalLink } from 'lucide-react';

const Webpages: React.FC = () => {
  const { webpages, addWebpage, updateWebpage, deleteWebpage } = useData();
  const { showError } = useError();
  const { confirm } = usePopup();
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    url: '',
    icon: '',
    stretch: false,
  });

  const filteredWebpages = webpages
    .filter(webpage =>
      webpage.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      webpage.url.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const handleFileUpload = async (file: File) => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      return new Promise<string>((resolve, reject) => {
        img.onload = () => {
          const maxDim = 96;
          const scale = Math.min(maxDim / img.width, maxDim / img.height, 1);
          const w = Math.max(1, Math.round(img.width * scale));
          const h = Math.max(1, Math.round(img.height * scale));
          
          canvas.width = w;
          canvas.height = h;
          ctx?.drawImage(img, 0, 0, w, h);
          
          try {
            const dataUrl = canvas.toDataURL('image/webp', 0.7);
            resolve(dataUrl);
          } catch (e) {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = () => reject(new Error('File read error'));
            reader.readAsDataURL(file);
          }
        };
        img.onerror = () => reject(new Error('Invalid image'));
        
        const reader = new FileReader();
        reader.onload = () => img.src = reader.result as string;
        reader.onerror = () => reject(new Error('File read error'));
        reader.readAsDataURL(file);
      });
    } catch (error) {
      throw new Error('Failed to process image');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.url.trim()) {
      showError('Name and URL are required');
      return;
    }

    try {
      if (editingId) {
        updateWebpage(editingId, formData);
      } else {
        if (!formData.icon) {
          showError('Please upload an icon');
          return;
        }
        addWebpage(formData);
      }
      
      setFormData({ name: '', url: '', icon: '', stretch: false });
      setEditingId(null);
      setIsModalOpen(false);
    } catch (error) {
      showError('Failed to save webpage');
    }
  };

  const handleEdit = (webpage: any) => {
    setFormData({
      name: webpage.name,
      url: webpage.url,
      icon: webpage.icon,
      stretch: webpage.stretch,
    });
    setEditingId(webpage.id);
    setIsModalOpen(true);
  };

  const handleDelete = (id: string, name: string) => {
    confirm(
      `Are you sure you want to delete "${name}"?`,
      () => deleteWebpage(id),
      {
        title: 'Delete Webpage',
        showDontAskAgain: true,
        skipKey: 'deleteWebpage'
      }
    );
  };

  const toggleStretch = (id: string, currentStretch: boolean) => {
    updateWebpage(id, { stretch: !currentStretch });
  };

  const exportWebpages = () => {
    try {
      const dataStr = JSON.stringify(webpages, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `webpages_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showError('Webpages exported successfully!', 'info');
    } catch (error) {
      showError('Failed to export webpages');
    }
  };

  const importWebpages = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result as string);
        if (Array.isArray(data)) {
          data.forEach(webpage => {
            if (webpage.name && webpage.url) {
              addWebpage({
                name: webpage.name,
                url: webpage.url,
                icon: webpage.icon || '',
                stretch: webpage.stretch || false
              });
            }
          });
          showError('Webpages imported successfully!', 'info');
        } else {
          throw new Error('Invalid format');
        }
      } catch (error) {
        showError('Invalid JSON file format');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white">🌐 Website Management</h2>
          <p className="text-slate-300">Manage your website bookmarks and shortcuts</p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={exportWebpages}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
          >
            <Download className="w-4 h-4 mr-2" />
            Export JSON
          </button>
          <label className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 cursor-pointer">
            <Upload className="w-4 h-4 mr-2" />
            Import JSON
            <input
              type="file"
              accept=".json"
              onChange={(e) => e.target.files?.[0] && importWebpages(e.target.files[0])}
              className="hidden"
            />
          </label>
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center px-4 py-2 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Webpage
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
        <input
          type="text"
          placeholder="Search webpages..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
        />
      </div>

      {/* Webpages Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {filteredWebpages.map((webpage) => {
          const actions = [
            {
              label: 'Open Link',
              icon: <ExternalLink className="w-4 h-4" />,
              action: () => window.open(webpage.url, '_blank'),
              variant: 'success' as const
            },
            {
              label: 'Edit',
              icon: <Edit className="w-4 h-4" />,
              action: () => handleEdit(webpage),
              variant: 'default' as const
            },
            {
              label: 'Delete',
              icon: <Trash2 className="w-4 h-4" />,
              action: () => handleDelete(webpage.id, webpage.name),
              variant: 'danger' as const
            }
          ];

          return (
            <div key={webpage.id} className="group relative bg-gradient-to-br from-blue-700 to-blue-800 border border-indigo-600 rounded-xl p-4 hover:transform hover:-translate-y-1 transition-all duration-200 hover:shadow-xl cursor-pointer">
              <div className="relative" onClick={() => window.open(webpage.url, '_blank')}>
                <div className="w-20 h-20 mx-auto mb-3 rounded-xl overflow-hidden bg-slate-900 flex items-center justify-center relative">
                  {webpage.icon ? (
                    <img 
                      src={webpage.icon} 
                      alt={webpage.name}
                      className={`w-full h-full ${webpage.stretch ? 'object-fill' : 'object-cover'} rounded-xl`}
                    />
                  ) : (
                    <Globe className="w-10 h-10 text-slate-400" />
                  )}
                  
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleStretch(webpage.id, webpage.stretch);
                    }}
                    className="absolute top-1 right-1 p-1 bg-black bg-opacity-50 text-white rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                    title={webpage.stretch ? 'Fit image' : 'Stretch image'}
                  >
                    {webpage.stretch ? <Minimize className="w-3 h-3" /> : <Maximize className="w-3 h-3" />}
                  </button>
                </div>
              </div>
              
              <h3 className="text-white font-medium text-center text-sm mb-2 line-clamp-2 min-h-[2.5rem]">
                {webpage.name}
              </h3>
              
              <div className="absolute inset-0 bg-black bg-opacity-50 rounded-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <ActionDropdown actions={actions} />
              </div>
            </div>
          );
        })}
      </div>

      {filteredWebpages.length === 0 && (
        <div className="text-center py-12">
          <Globe className="mx-auto h-12 w-12 text-slate-400" />
          <h3 className="mt-2 text-sm font-medium text-white">No webpages found</h3>
          <p className="mt-1 text-sm text-slate-400">
            {searchQuery ? 'Try adjusting your search criteria' : 'Get started by adding your first webpage'}
          </p>
        </div>
      )}

      {/* Add/Edit Webpage Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-lg shadow-xl max-w-md w-full border border-slate-600">
            <div className="p-6 border-b border-slate-600">
              <h3 className="text-lg font-semibold text-white">
                {editingId ? 'Edit Webpage' : 'Add New Webpage'}
              </h3>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Website Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Website URL *
                </label>
                <input
                  type="url"
                  value={formData.url}
                  onChange={(e) => setFormData(prev => ({ ...prev, url: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                  placeholder="https://example.com"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Icon {!editingId && '*'}
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      try {
                        const icon = await handleFileUpload(file);
                        setFormData(prev => ({ ...prev, icon }));
                      } catch (error) {
                        showError('Failed to process image');
                      }
                    }
                  }}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                  required={!editingId}
                />
                {formData.icon && (
                  <div className="mt-2 flex items-center space-x-2">
                    <img src={formData.icon} alt="Preview" className="w-8 h-8 rounded" />
                    <span className="text-sm text-slate-400">Icon preview</span>
                  </div>
                )}
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingId(null);
                    setFormData({ name: '', url: '', icon: '', stretch: false });
                  }}
                  className="px-4 py-2 border border-slate-600 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors duration-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-yellow-500 text-slate-900 rounded-lg hover:bg-yellow-400 transition-colors duration-200 font-medium"
                >
                  {editingId ? 'Update' : 'Add'} Webpage
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Webpages;