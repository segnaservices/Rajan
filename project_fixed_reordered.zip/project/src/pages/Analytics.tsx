import React from 'react';
import { useData } from '../contexts/DataContext';
import { TrendingUp, DollarSign, ShoppingBag, Users } from 'lucide-react';

const Analytics: React.FC = () => {
  const { salesEntries, customers, products } = useData();

  // Calculate analytics data
  const totalRevenue = salesEntries.reduce((sum, entry) => sum + entry.totalAmount, 0);
  const completedSales = salesEntries.filter(entry => entry.status === 'completed');
  const averageOrderValue = completedSales.length > 0 ? totalRevenue / completedSales.length : 0;

  // Monthly revenue calculation
  const monthlyRevenue = salesEntries.reduce((acc, entry) => {
    const month = new Date(entry.date).toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
    acc[month] = (acc[month] || 0) + entry.totalAmount;
    return acc;
  }, {} as { [key: string]: number });

  // Top products
  const productSales = salesEntries.reduce((acc, entry) => {
    acc[entry.productName] = (acc[entry.productName] || 0) + entry.quantity;
    return acc;
  }, {} as { [key: string]: number });

  const topProducts = Object.entries(productSales)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  // Top customers
  const customerSales = salesEntries.reduce((acc, entry) => {
    acc[entry.customerName] = (acc[entry.customerName] || 0) + entry.totalAmount;
    return acc;
  }, {} as { [key: string]: number });

  const topCustomers = Object.entries(customerSales)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  const analyticsCards = [
    {
      title: 'Total Revenue',
      value: `$${totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'bg-green-500',
      change: '+15.3%',
    },
    {
      title: 'Total Orders',
      value: salesEntries.length,
      icon: ShoppingBag,
      color: 'bg-blue-500',
      change: '+8.7%',
    },
    {
      title: 'Average Order Value',
      value: `$${Math.round(averageOrderValue).toLocaleString()}`,
      icon: TrendingUp,
      color: 'bg-purple-500',
      change: '+12.1%',
    },
    {
      title: 'Active Customers',
      value: customers.length,
      icon: Users,
      color: 'bg-indigo-500',
      change: '+5.2%',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {analyticsCards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.title} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{card.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{card.value}</p>
                  <p className="text-sm text-green-600 font-medium mt-1">{card.change}</p>
                </div>
                <div className={`p-3 rounded-lg ${card.color} bg-opacity-10`}>
                  <Icon className={`w-6 h-6 ${card.color.replace('bg-', 'text-')}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts and Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Revenue */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Monthly Revenue</h3>
          </div>
          <div className="p-6">
            {Object.keys(monthlyRevenue).length > 0 ? (
              <div className="space-y-4">
                {Object.entries(monthlyRevenue).map(([month, revenue]) => (
                  <div key={month} className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">{month}</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${(revenue / Math.max(...Object.values(monthlyRevenue))) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-semibold text-gray-900">${revenue.toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">No revenue data available</p>
            )}
          </div>
        </div>

        {/* Top Products */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Top Products</h3>
          </div>
          <div className="p-6">
            {topProducts.length > 0 ? (
              <div className="space-y-4">
                {topProducts.map(([productName, quantity], index) => (
                  <div key={productName} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white ${
                        index === 0 ? 'bg-yellow-500' : 
                        index === 1 ? 'bg-gray-400' : 
                        index === 2 ? 'bg-amber-600' : 'bg-gray-300'
                      }`}>
                        {index + 1}
                      </div>
                      <span className="text-sm font-medium text-gray-700">{productName}</span>
                    </div>
                    <span className="text-sm font-semibold text-gray-900">{quantity} sold</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">No sales data available</p>
            )}
          </div>
        </div>

        {/* Top Customers */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 lg:col-span-2">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Top Customers by Revenue</h3>
          </div>
          <div className="p-6">
            {topCustomers.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {topCustomers.map(([customerName, revenue]) => (
                  <div key={customerName} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">{customerName}</span>
                    <span className="text-sm font-semibold text-gray-900">${revenue.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">No customer data available</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;