import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.get("/rates", async (req, res) => {
  try {
    const response = await client.responses.create({
      model: "gpt-5",
      input: `
        Provide today's 22K gold rate (per gram, INR) and silver rate (per gram, INR) in Chennai.
        Also give the last 7 days history for both, in strict JSON format:

        {
          "gold": [
            { "date": "YYYYMMDD", "price": <number> }
          ],
          "silver": [
            { "date": "YYYYMMDD", "price": <number> }
          ],
          "summaries": {
            "gold": "short gold summary",
            "silver": "short silver summary"
          }
        }

        Output ONLY valid JSON.
      `,
    });

    const text = response.output[0].content[0].text.trim();
    const data = JSON.parse(text);

    res.json(data);
  } catch (err) {
    console.error("❌ Backend error:", err);
    res.status(500).json({ error: "Failed to fetch rates" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Backend running at http://localhost:${PORT}`));
